# Plan Maestro de Implementación Revisado — Fase 4.2.6
## Fusión y Arbitraje Multifuente (`EvidenceBundle` & `NormativeGuard`)

**Proyecto:** IJF SOR Assistant  
**Fase:** 4.2.6 — Fusión y Arbitraje Multifuente  
**Supervisor y Autoridad Soberana de Aprobación:** Alexis Oliveros Lozano  
**Arquitectura y Auditoría Independiente:** ChatGPT  
**Ejecutor Técnico:** Antigravity  
**Fecha:** 2026-11-05 (Versión v2.7 — Corrección Integral de Auditoría Independiente H-426-V26)  
**Repositorio:** `C:\PROYECTOS\IJF-SOR-Assistant`  
**Branch:** `integration/ijf-sor-2026-08-merge`  
**Estado:** **EXPEDIENTE DE PLANIFICACIÓN TÉCNICA — CÓDIGO NO IMPLEMENTADO**

---

## 1. Objetivos, Alcance y Exclusiones

### 1.1 Objetivo General
Implementar incrementalmente en código funcional y probado la arquitectura de fusión y arbitraje multifuente definida en el diseño técnico aprobado, garantizando la prevalencia jerárquica y ontológica absoluta del corpus canónico SOR 2026, la contención determinista y formalizada de riesgos normativos mediante `NormativeGuard` (basada exclusivamente en la comparación estructural de proposiciones deónticas completas, erradicando cualquier heurística residual de palabras clave o menciones incidentales), y la estricta invarianza del RRE y de las respuestas ADA ante consultas canónicas puras y fuera de dominio.

### 1.2 Alcance Autorizado para Futura Ejecución
1. Creación de los modelos de datos tipados y contratos de gobernanza (`src/evidence_bundle.py`).
2. Creación del componente de barrera de seguridad normativa formalizada (`src/normative_guard.py`).
3. Creación del motor de arbitraje jerárquico desacoplado (`src/multisource_arbitrator.py`).
4. Homogeneización de parámetros de búsqueda en `src/rre_engine.py` (`min_score=3.0`, `min_overlap_ratio=0.25`).
5. Integración del pipeline de fusión en `src/rre_engine.py` bajo feature flag tri-estado desacoplado (`enable_multisource_fusion: Optional[bool] = None`, por defecto resuelto a `False`).
6. Creación de suites de pruebas unitarias, de integración, de invarianza y de seguridad crítica.
7. Construcción y ejecución del dataset hold-out reservado de certificación independiente (20 casos hold-out) con custodia auditada y exigencia de cero fallos en los 4 casos de seguridad crítica.

### 1.3 Exclusiones Explícitas (Fuera de Alcance)
- Modificación de corpus canónico SOR 2026 o de índices FAISS existentes.
- Ingestión de nuevos Sidecars no catalogados en el batch 2026-11-01.
- Alteración de los 267 tests base del repositorio.
- Intervenciones directas en entornos OCI o despliegues productivos.
- Operaciones de Git remoto (`push`, `merge`, `pr`).
- Inicio de la Fase 4.2.7 (Síntesis Generativa Multifuente).

---

## 2. Arquitectura Aprobada y Flujo de Procesamiento

El arbitraje multifuente opera como una capa intermedia entre la recuperación de evidencias y la generación de respuestas, desacoplada y modular:

```
                  ┌────────────────────────────────────────────────┐
                  │                 User Query                     │
                  └───────────────────────┬────────────────────────┘
                                          │
                                          ▼
                  ┌────────────────────────────────────────────────┐
                  │           ReasoningRetrievalEngine             │
                  │   - Canonical RRF Retrieval (BM25 + Dense)     │
                  │   - Multifuente Sidecar Search (Calibrada)     │
                  └───────────────────────┬────────────────────────┘
                                          │
                    ┌─────────────────────┴─────────────────────┐
                    │                                           │
                    ▼                                           ▼
         ┌─────────────────────┐                     ┌─────────────────────┐
         │ Primary Candidates  │                     │ Sidecar Candidates  │
         │ (Canonical SOR 2026)│                     │ (Staged/Ingested)   │
         └──────────┬──────────┘                     └──────────┬──────────┘
                    │                                           │
                    └─────────────────────┬─────────────────────┘
                                          │
                                          ▼
                  ┌────────────────────────────────────────────────┐
                  │             NormativeGuard Pipeline            │
                  │  1. Extracción de Candidatos y Catalogación    │
                  │  2. Mapeo a Proposiciones Deónticas Formativas │
                  │  3. Comparación Dispositiva Componente a       │
                  │     Componente (Sujeto, Acción, Operador, etc.)│
                  │  4. Decisión Consistente e Invariantes Salida  │
                  └───────────────────────┬────────────────────────┘
                                          │
                                          ▼
                  ┌────────────────────────────────────────────────┐
                  │              MultisourceArbitrator             │
                  │  - Reglas de Precedencia Jerárquica            │
                  │  - Validación de Vigencia y Alcance            │
                  │  - Evaluación Copulativa de Suficiencia        │
                  │    (5 Condiciones con Evidencia Válida)        │
                  └───────────────────────┬────────────────────────┘
                                          │
                                          ▼
                  ┌────────────────────────────────────────────────┐
                  │                 EvidenceBundle                 │
                  │  - primary_items (Invariantes SOR)             │
                  │  - sidecar_items (Filtrados/Admisibles)        │
                  │  - arbitration_decision (Tipada)               │
                  │  - normative_guard_result (Invariantes OK)     │
                  │  - sufficiency_evaluation (Audit Reasons)      │
                  └────────────────────────────────────────────────┘
```

---

## 3. Contratos de Datos y Modelos Tipados (v2.7)

Se formalizan los modelos en `src/evidence_bundle.py`, integrando el cálculo determinista del hash de provenance que cubre la totalidad de campos materiales incluyendo `ScopeApplicability` (H-426-V25-04), la severidad cerrada (H-426-V24-06), la gobernanza sin simulación de validadores (H-426-V24-07), el enum cerrado de acciones y la tabla de invariantes exhaustiva de `NormativeGuardResult` (H-426-V26-02), la formalización rigurosa de proposiciones normativas (H-426-V26-01) y la evaluación de suficiencia respaldada por evidencia verificable no vacía (H-426-V26-05):

```python
from dataclasses import dataclass, field
from enum import Enum
from typing import List, Dict, Any, Optional
import hashlib
import json

class AuthorityTier(Enum):
    TIER_1_CANONICAL = "TIER_1_CANONICAL"              # SOR 2026 Oficial del Comité Ejecutivo IJF
    TIER_2_OFFICIAL_AMENDMENT = "TIER_2_OFFICIAL_AMENDMENT"  # Circulares Oficiales del Comité Ejecutivo
    TIER_3_TECHNICAL_INTERPRETATION = "TIER_3_TECHNICAL_INTERPRETATION"  # Seminarios y presentaciones técnicas
    TIER_4_CONTEXTUAL = "TIER_4_CONTEXTUAL"            # Glosarios, notas pedagógicas e histórico

class NormativeValidity(Enum):
    """Vigencia jurídica formal del documento fuente (Gobernanza documental)."""
    CONFIRMED_CURRENT = "CONFIRMED_CURRENT"          # Vigente y ratificada con evidencia externa contrastada
    PENDING_VALIDATION = "PENDING_VALIDATION"        # Declarada en manifiesto, pendiente de contraste oficial
    UNKNOWN = "UNKNOWN"                              # Estado de vigencia no determinable; inadmisible
    SUPERSEDED = "SUPERSEDED"                        # Reemplazada formalmente por circular posterior
    EXPIRED = "EXPIRED"                              # Plazo temporal o evento de aplicación concluido

class EvidenceLifecycleState(Enum):
    """Estado técnico de procesamiento y admisibilidad del fragmento individual en el pipeline."""
    RETRIEVED = "RETRIEVED"            # Extraído por el motor léxico/vectorial
    VALIDATED = "VALIDATED"            # Superó integridad criptográfica y elegibilidad básica
    ADMISSIBLE = "ADMISSIBLE"          # Pertinente, dentro de alcance y apto para deliberación
    CONTEXTUAL = "CONTEXTUAL"          # Válido como trasfondo pedagógico, sin valor dispositivo
    CONTRADICTORY = "CONTRADICTORY"    # En conflicto directo con una norma superior
    REJECTED = "REJECTED"              # Descartado por violación de seguridad, expiración o ruido

class ArbitrationDecision(Enum):
    """Decisiones formales tipadas de arbitraje multifuente."""
    CANONICAL_EXCLUSIVE = "CANONICAL_EXCLUSIVE"      # Solo evidencia canónica SOR (consultas puras o sidecar no admisible)
    HARMONIZED_SUPPLEMENT = "HARMONIZED_SUPPLEMENT"  # Fusión armónica con especificación complementaria
    OFFICIAL_MODIFICATION = "OFFICIAL_MODIFICATION"  # Enmienda ejecutiva Tier 2 modifica regla canónica
    GUARD_REJECTION = "GUARD_REJECTION"              # Rechazo activo por barrera de seguridad normativa
    CONSERVATIVE_ABSTENTION = "CONSERVATIVE_ABSTENTION" # Conflicto irresoluble o no clasificado; abstención

class GuardActionTaken(Enum):
    """Enum cerrado para acciones deterministas tomadas por NormativeGuard (H-426-V26-02)."""
    PERMIT = "PERMIT"                                     # Admisión limpia total sin violaciones ni rechazos
    PURGE_EXCEPTIONS = "PURGE_EXCEPTIONS"                 # Purga selectiva de sidecars conflictivos; retención de válidos
    BLOCK_ALL_SIDECAR = "BLOCK_ALL_SIDECAR"               # Bloqueo total de sidecars; bundle canónico exclusivo
    CONSERVATIVE_FALLBACK = "CONSERVATIVE_FALLBACK"       # Conflicto semántico, falta de estructura o ambigüedad irresoluble

class AgeCategory(Enum):
    ALL_AGES = "ALL_AGES"
    SENIOR_ONLY = "SENIOR_ONLY"
    JUNIOR = "JUNIOR"
    CADET = "CADET"
    UNKNOWN_CONTEXT = "UNKNOWN_CONTEXT"

class CompetitionType(Enum):
    WORLD_JUDO_TOUR = "WORLD_JUDO_TOUR"  # Grand Slam, Grand Prix, Masters, Mundiales
    OLYMPIC_GAMES = "OLYMPIC_GAMES"
    NATIONAL_REGIONAL = "NATIONAL_REGIONAL"
    UNKNOWN_CONTEXT = "UNKNOWN_CONTEXT"

@dataclass(frozen=True)
class ScopeApplicability:
    age_category: AgeCategory
    competition_type: CompetitionType
    modality: str  # e.g., "INDIVIDUAL", "MIXED_TEAM"
    valid_from_event: str  # e.g., "GS Ulaanbaatar 2026"
    valid_until_event: Optional[str] = None  # e.g., "LA28 Olympic Games"
    cadet_junior_excluded: bool = False

    def to_canonical_dict(self) -> Dict[str, Any]:
        """Serialización canónica normalizada para cómputo de integridad criptográfica."""
        return {
            "age_category": self.age_category.value,
            "cadet_junior_excluded": self.cadet_junior_excluded,
            "competition_type": self.competition_type.value,
            "modality": self.modality.strip().upper(),
            "valid_from_event": self.valid_from_event.strip(),
            "valid_until_event": self.valid_until_event.strip() if self.valid_until_event is not None else None
        }

class DeonticOperator(Enum):
    """Operador deóntico formalizado (H-426-V26-01)."""
    PROHIBITION = "PROHIBITION"        # Prohibición (no se debe / prohibido / penalizado)
    OBLIGATION = "OBLIGATION"          # Obligación (se debe / obligatorio / shall)
    PERMISSION = "PERMISSION"          # Permisión positiva (se permite / allowed / authorized)
    EXCEPTION = "EXCEPTION"            # Excepción condicionada a una prohibición u obligación

class NormativeSanction(Enum):
    """Sanciones canónicas tipadas de la IJF."""
    IPPON = "IPPON"
    WAZA_ARI = "WAZA_ARI"
    YUKO = "YUKO"
    SHIDO = "SHIDO"
    HANSOKU_MAKE_DIRECT = "HANSOKU_MAKE_DIRECT"
    HANSOKU_MAKE_INDIRECT = "HANSOKU_MAKE_INDIRECT"
    NO_SANCTION = "NO_SANCTION"
    NO_SCORE = "NO_SCORE"

class NormativeDisposition(Enum):
    IMPERATIVE_PROHIBITION = "IMPERATIVE_PROHIBITION"  # Prohibición absoluta (ej. Hansoku-make directo)
    POSITIVE_AUTHORIZATION = "POSITIVE_AUTHORIZATION"  # Acción permitida (ej. Reverse seoi-nage en Senior)
    CONDITIONAL_EXCEPTION = "CONDITIONAL_EXCEPTION"    # Excepción condicionada estricta
    TECHNICAL_DEFINITION = "TECHNICAL_DEFINITION"      # Definición de puntuación o concepto (ej. Yuko 5-9s)
    PROCEDURAL_INSTRUCTION = "PROCEDURAL_INSTRUCTION"  # Criterio operativo de fluidez arbitral

class RelationType(Enum):
    CONCORDANT = "CONCORDANT"          # Ratifica o coincide con el SOR sin modificarlo
    SPECIFICATION = "SPECIFICATION"    # Detalla un procedimiento operativo no explicitado en el SOR
    AMENDMENT = "AMENDMENT"            # Modifica una regla canónica preexistente (solo Tier 2 oficial)
    INTERPRETATIVE_GUIDANCE = "INTERPRETATIVE_GUIDANCE"  # Guía arbitral para juzgar acciones continuas
    CONFLICT_OVERRIDDEN = "CONFLICT_OVERRIDDEN"  # Conflicto neutralizado por prevalencia canónica

class ViolationSeverity(Enum):
    """Nivel de severidad cerrado para violaciones de seguridad normativa (H-426-V24-06)."""
    CRITICAL = "CRITICAL"  # Violación grave de seguridad; purga o bloqueo forzoso
    WARNING = "WARNING"    # Conflicto de interpretación menor o atenuante no crítico
    INFO = "INFO"          # Nota informativa de alcance o contexto

@dataclass(frozen=True)
class NormativeProposition:
    """Representación formalizada de una proposición normativa (H-426-V26-01)."""
    subject: str                                       # Sujeto: 'tori', 'uke', 'referee', 'athlete'
    action: str                                        # Acción técnica o conducta: 'head_bridge_landing', 'kansetsu_waza_knee'
    deontic_operator: DeonticOperator                  # Operador: PROHIBITION, OBLIGATION, PERMISSION, EXCEPTION
    target_object: str                                 # Objeto o zona afectada: 'neck_spine', 'elbow_joint', 'belt_skirt'
    conditions: List[str]                              # Condiciones operativas de activación
    exceptions: List[str]                              # Excepciones declaradas explícitamente
    scope: ScopeApplicability                          # Alcance categorial, temporal y de evento
    sanction: NormativeSanction                        # Sanción o consecuencia jurídica
    authority_tier: AuthorityTier                      # Nivel de autoridad del emisor
    document_ref: str                                  # Referencia documental canónica o sidecar
    article_ref: Optional[str] = None                  # Artículo específico (ej. '14', '18.1', '18.2')

@dataclass(frozen=True)
class ProvenanceInfo:
    """Trazabilidad exhaustiva de gobernanza y procedencia documental con cálculo criptográfico completo (H-426-V25-04)."""
    document_id: str
    authority_tier: AuthorityTier
    validity: NormativeValidity
    scope: ScopeApplicability
    source_url: str
    staging_sha256: str
    official_gazette_reference: Optional[str] = None
    issuing_body: str = "IJF Executive Committee"
    promulgation_date: str = ""
    recorded_by: str = "Ingestion Pipeline"
    validated_by: Optional[str] = None
    validation_evidence_ref: Optional[str] = None
    verification_timestamp: float = 0.0
    page_or_slide: Optional[int] = None

    def compute_verification_hash(self) -> str:
        """
        Calcula el hash SHA-256 determinista cubriendo TODOS los campos materiales (H-426-V25-04).
        Aplica normalización canónica JSON con claves ordenadas, separadores compactos y UTF-8.
        """
        payload_dict = {
            "authority_tier": self.authority_tier.value,
            "document_id": self.document_id.strip(),
            "issuing_body": self.issuing_body.strip(),
            "official_gazette_reference": self.official_gazette_reference.strip() if self.official_gazette_reference is not None else None,
            "page_or_slide": self.page_or_slide,
            "promulgation_date": self.promulgation_date.strip(),
            "recorded_by": self.recorded_by.strip(),
            "scope": self.scope.to_canonical_dict(),
            "source_url": self.source_url.strip(),
            "staging_sha256": self.staging_sha256.strip().lower(),
            "validated_by": self.validated_by.strip() if self.validated_by is not None else None,
            "validation_evidence_ref": self.validation_evidence_ref.strip() if self.validation_evidence_ref is not None else None,
            "validity": self.validity.value,
            "verification_timestamp": float(self.verification_timestamp)
        }
        canonical_json = json.dumps(payload_dict, sort_keys=True, separators=(",", ":"), ensure_ascii=False)
        return hashlib.sha256(canonical_json.encode("utf-8")).hexdigest()

@dataclass
class EvidenceItem:
    evidence_id: str
    title: str
    content_text: str
    article_id: Optional[str]
    score: float
    overlap_ratio: float
    provenance: ProvenanceInfo
    lifecycle_state: EvidenceLifecycleState
    disposition: NormativeDisposition
    relation_to_canonical: RelationType
    proposition: Optional[NormativeProposition] = None  # Proposición estructurada formalizada
    rejection_reason: Optional[str] = None

@dataclass
class GuardViolation:
    rule_id: str
    severity: ViolationSeverity
    article_id: Optional[str]
    description: str
    rejected_evidence_id: str  # Obligatorio: toda violación identifica evidencia concreta (H-426-V26-02)

@dataclass
class NormativeGuardResult:
    """Resultado estructurado y auditable de la evaluación del NormativeGuard con invariantes exhaustivos (H-426-V26-02)."""
    passed: bool
    retained_sidecars: List[EvidenceItem]
    rejected_sidecars: List[EvidenceItem]
    violations: List[GuardViolation]
    evaluation_log: List[str]
    action_taken: GuardActionTaken  # Enum cerrado (H-426-V26-02)

    def __post_init__(self):
        """Validación exhaustiva de consistencia de invariantes (H-426-V26-02)."""
        critical_violations = [v for v in self.violations if v.severity == ViolationSeverity.CRITICAL]
        warning_violations = [v for v in self.violations if v.severity == ViolationSeverity.WARNING]
        info_violations = [v for v in self.violations if v.severity == ViolationSeverity.INFO]
        
        rejected_ids = {item.evidence_id for item in self.rejected_sidecars}
        retained_ids = {item.evidence_id for item in self.retained_sidecars}

        # Invariante 1: No intersección entre retained y rejected
        overlap = retained_ids.intersection(rejected_ids)
        if overlap:
            raise ValueError(f"Invariante violado: Evidencias {overlap} están en retained y rejected simultáneamente.")

        # Invariante 2: Toda violación debe identificar un rejected_evidence_id válido y no vacío
        for v in self.violations:
            if not v.rejected_evidence_id or not v.rejected_evidence_id.strip():
                raise ValueError(f"Invariante violado: Violación {v.rule_id} no identifica evidencia rechazada (rejected_evidence_id vacío).")

        # Invariante 3: Si existen violaciones CRITICAL -> passed DEBE ser False
        if critical_violations:
            if self.passed is not False:
                raise ValueError("Invariante violado: passed debe ser False si existen violaciones CRITICAL.")
            if self.action_taken not in {GuardActionTaken.PURGE_EXCEPTIONS, GuardActionTaken.BLOCK_ALL_SIDECAR, GuardActionTaken.CONSERVATIVE_FALLBACK}:
                raise ValueError(f"Invariante violado: action_taken no puede ser '{self.action_taken.value}' ante violaciones CRITICAL.")
            
            # Toda evidencia con violación CRITICAL debe estar en rejected_sidecars y nunca en retained
            for cv in critical_violations:
                if cv.rejected_evidence_id in retained_ids:
                    raise ValueError(f"Invariante violado: Evidencia {cv.rejected_evidence_id} con violación CRITICAL está retenida.")
                if cv.rejected_evidence_id not in rejected_ids:
                    raise ValueError(f"Invariante violado: Evidencia {cv.rejected_evidence_id} con violación CRITICAL no figura en rejected_sidecars.")

        # Invariante 4: Si passed == True -> Cero violaciones CRITICAL
        if self.passed is True and critical_violations:
            raise ValueError("Invariante violado: passed no puede ser True si existen violaciones CRITICAL.")

        # Invariante 5: Política explícita para WARNING e INFO
        # Las advertencias (WARNING) o notas informativas (INFO) sin violaciones CRITICAL no impiden passed=True,
        # pero si un elemento fue rechazado administrativamente (ej. expiración o scope), se purga con PURGE_EXCEPTIONS.
        if not critical_violations and self.rejected_sidecars:
            if self.action_taken not in {GuardActionTaken.PURGE_EXCEPTIONS, GuardActionTaken.BLOCK_ALL_SIDECAR, GuardActionTaken.CONSERVATIVE_FALLBACK}:
                raise ValueError(f"Invariante violado: Con rechazos presentes, action_taken debe ser PURGE_EXCEPTIONS, BLOCK_ALL_SIDECAR o CONSERVATIVE_FALLBACK, no '{self.action_taken.value}'.")

        # Invariante 6: Estado limpio total
        if not self.violations and not self.rejected_sidecars:
            if self.passed is not True:
                raise ValueError("Invariante violado: passed debe ser True si no hay violaciones ni rechazos.")
            if self.action_taken != GuardActionTaken.PERMIT:
                raise ValueError(f"Invariante violado: action_taken debe ser PERMIT en ausencia de violaciones o rechazos, no '{self.action_taken.value}'.")

### Tabla de Estados de Invariantes de NormativeGuardResult (H-426-V26-02)

| Violaciones CRITICAL | Violaciones WARNING/INFO | Sidecars Rechazados | Sidecars Retenidos | `passed` | `action_taken` Válido | Estado Lógico |
| :---: | :---: | :---: | :---: | :---: | :--- | :--- |
| **0** | **0** | **0** | $\ge 0$ | `True` | `PERMIT` | **VÁLIDO (Limpio)** |
| **0** | $\ge 0$ | $> 0$ | $\ge 0$ | `True` | `PURGE_EXCEPTIONS` / `BLOCK_ALL_SIDECAR` | **VÁLIDO (Rechazo no crítico)** |
| $> 0$ | $\ge 0$ | $> 0$ | $> 0$ | `False` | `PURGE_EXCEPTIONS` | **VÁLIDO (Purga selectiva crítica)** |
| $> 0$ | $\ge 0$ | $> 0$ | **0** | `False` | `BLOCK_ALL_SIDECAR` | **VÁLIDO (Bloqueo total crítico)** |
| Cualquiera | Cualquiera | $\ge 0$ | $\ge 0$ | `False` | `CONSERVATIVE_FALLBACK` | **VÁLIDO (Abstención conservadora)** |
| $> 0$ | Cualquiera | Cualquiera | Cualquiera | `True` | Cualquiera | **INVÁLIDO (passed no puede ser True con CRITICAL)** |
| $> 0$ | Cualquiera | Cualquiera | Cualquiera | `False` | `PERMIT` | **INVÁLIDO (action_taken no puede ser PERMIT con CRITICAL)** |
| Cualquiera | Cualquiera | Contiene ID $X$ | Contiene ID $X$ | Cualquiera | Cualquiera | **INVÁLIDO (Intersección no vacía entre retained y rejected)** |

@dataclass
class ConditionVerificationEvidence:
    """Evidencia auditable que respalda formalmente cada condición de suficiencia con validación sustantiva (H-426-V26-05)."""
    condition_name: str
    required_evidence_type: str                         # e.g., 'OFFICIAL_GAZETTE_MATCH', 'REGISTRY_RATIFICATION'
    documentary_reference: str                          # e.g., 'IJF Circular 2026-08 Art 14', 'Manifest BATCH-2026-11-01'
    source_origin: str                                  # e.g., 'IJF Executive Committee Official Portal'
    responsible_agent: str                              # e.g., 'Alexis Oliveros Lozano', 'Data Governance Gatekeeper'
    verification_passed: bool                           # True si la evidencia fue contrastada y es válida
    failure_reason: Optional[str] = None                # Detalle si falló o si es UNKNOWN

    def is_substantively_valid(self, expected_condition_name: str) -> bool:
        """Comprueba que la evidencia cumpla los 6 requisitos sustantivos indispensables (H-426-V26-05)."""
        # 1. Correspondencia unívoca con la condición concreta
        if self.condition_name.strip() != expected_condition_name.strip():
            return False
        # 2. Tipo de evidencia no vacío
        if not self.required_evidence_type or not self.required_evidence_type.strip():
            return False
        # 3. Referencia documental identificable y no vacía
        if not self.documentary_reference or not self.documentary_reference.strip() or self.documentary_reference.strip().upper() == "UNKNOWN":
            return False
        # 4. Origen de la fuente no vacío y rastreable
        if not self.source_origin or not self.source_origin.strip() or self.source_origin.strip().upper() == "UNKNOWN":
            return False
        # 5. Agente responsable no vacío ni genérico
        if not self.responsible_agent or not self.responsible_agent.strip() or self.responsible_agent.strip().upper() == "UNKNOWN":
            return False
        # 6. Resultado explícito de validación superado
        return self.verification_passed is True

@dataclass
class SufficiencyEvaluationResult:
    """Evaluación auditable respaldada por evidencia verificable de las 5 condiciones copulativas (H-426-V26-05)."""
    is_sufficient: bool
    authority_validated: bool
    validity_confirmed: bool
    scope_pertinent: bool
    normative_guard_clean: bool
    no_unresolved_conflicts: bool
    condition_evidences: Dict[str, ConditionVerificationEvidence] = field(default_factory=dict)
    audit_reasons: List[str] = field(default_factory=list)

    def evaluate_copulative(self) -> bool:
        """
        Comprueba copulativamente las 5 condiciones.
        Exige respaldo probatorio concreto y sustantivamente válido; rechaza booleanos aislados o UNKNOWN (H-426-V26-05).
        """
        self.audit_reasons.clear()
        required_keys = [
            "authority_validated", "validity_confirmed", "scope_pertinent",
            "normative_guard_clean", "no_unresolved_conflicts"
        ]
        
        all_passed = True
        for key in required_keys:
            ev = self.condition_evidences.get(key)
            if ev is None:
                all_passed = False
                self.audit_reasons.append(f"Condición '{key}' carece de objeto probatorio adjunto (Evidence is None).")
                continue
            
            # Validación sustantiva estricta de campos no vacíos y correspondencia
            if not ev.is_substantively_valid(expected_condition_name=key):
                all_passed = False
                reason = ev.failure_reason or "Evidencia incompleta, vacía, con valor UNKNOWN o inconsistente"
                self.audit_reasons.append(
                    f"Condición '{key}' NO aprobada por falta de sustento probatorio válido: {reason} "
                    f"[Tipo: '{ev.required_evidence_type}', Ref: '{ev.documentary_reference}', "
                    f"Origen: '{ev.source_origin}', Resp: '{ev.responsible_agent}']"
                )

        self.authority_validated = self.condition_evidences.get("authority_validated", ConditionVerificationEvidence("", "", "", "", "", False)).is_substantively_valid("authority_validated")
        self.validity_confirmed = self.condition_evidences.get("validity_confirmed", ConditionVerificationEvidence("", "", "", "", "", False)).is_substantively_valid("validity_confirmed")
        self.scope_pertinent = self.condition_evidences.get("scope_pertinent", ConditionVerificationEvidence("", "", "", "", "", False)).is_substantively_valid("scope_pertinent")
        self.normative_guard_clean = self.condition_evidences.get("normative_guard_clean", ConditionVerificationEvidence("", "", "", "", "", False)).is_substantively_valid("normative_guard_clean")
        self.no_unresolved_conflicts = self.condition_evidences.get("no_unresolved_conflicts", ConditionVerificationEvidence("", "", "", "", "", False)).is_substantively_valid("no_unresolved_conflicts")

        self.is_sufficient = all_passed and (len(self.audit_reasons) == 0)
        return self.is_sufficient

@dataclass
class EvidenceBundle:
    bundle_id: str
    query: str
    primary_items: List[EvidenceItem]
    sidecar_items: List[EvidenceItem]
    arbitration_decision: ArbitrationDecision
    normative_guard_result: NormativeGuardResult
    sufficiency_evaluation: SufficiencyEvaluationResult
    audit_trail: List[str]
    is_sufficient_for_synthesis: bool = False
    requires_context_disambiguation: bool = False
    metadata: Dict[str, Any] = field(default_factory=dict)
```

---

## 4. Contrato de Feature Flags, Fallbacks e Integración en RRE (H-426-V24-01)

### 4.1 Contrato del Feature Flag y Precedencia Tri-Estado
En `src/rre_engine.py`:
- **Parámetro Formal en Constructor:** `enable_multisource_fusion: Optional[bool] = None`.
- **Variable de Entorno:** `RRE_ENABLE_MULTISOURCE_FUSION`.
  - Valores reconocidos como `True`: `{"1", "true", "yes", "on"}` (case-insensitive, tras `strip()`).
  - Valores reconocidos como `False`: `{"0", "false", "no", "off"}`.
  - Variable vacía `""` o no definida: se interpreta como ausencia de configuración de entorno.
- **Regla Estricta de Precedencia:**
  1. Si `enable_multisource_fusion` es un booleano explícito (`True` o `False`), su valor prevalece de manera absoluta sobre cualquier valor de la variable de entorno.
  2. Si `enable_multisource_fusion is None`, se evalúa `os.environ.get("RRE_ENABLE_MULTISOURCE_FUSION")`:
     - Si la variable está definida y coincide con los valores verdaderos, resuelve a `True`.
     - Si coincide con valores falsos, resuelve a `False`.
     - Si no está definida o es inválida, se aplica el **fallback por defecto: `False`**.
  3. El valor resuelto se almacena en `self.enable_multisource_fusion: bool`.

### 4.2 Matriz de Casos de Prueba de Precedencia e Inicialización
| Caso | Parámetro en Constructor | Variable de Entorno | Valor Final Resuelto | Comportamiento del Motor |
| :--- | :--- | :--- | :--- | :--- |
| **FF-01** | `None` (Default) | No definida | `False` | Fusión apagada; motor canónico puro; 0 overhead. |
| **FF-02** | `None` | `RRE_ENABLE_MULTISOURCE_FUSION="1"` | `True` | Fusión activada vía entorno. |
| **FF-03** | `None` | `RRE_ENABLE_MULTISOURCE_FUSION="true"` | `True` | Fusión activada vía entorno. |
| **FF-04** | `None` | `RRE_ENABLE_MULTISOURCE_FUSION="0"` | `False` | Fusión apagada vía entorno. |
| **FF-05** | `None` | `RRE_ENABLE_MULTISOURCE_FUSION="invalid"`| `False` | Fallback de seguridad ante valor desconocido. |
| **FF-06** | `True` | No definida | `True` | Prevalencia explícita del parámetro. |
| **FF-07** | `True` | `RRE_ENABLE_MULTISOURCE_FUSION="0"` | `True` | Parámetro explícito `True` anula variable en `0`. |
| **FF-08** | `False` | `RRE_ENABLE_MULTISOURCE_FUSION="1"` | `False` | Parámetro explícito `False` anula variable en `1`. |
| **FF-09** | `False` | No definida | `False` | Parámetro explícito `False` ratificado. |

### 4.3 Comportamiento Desacoplado y Fallback ante Inactividad
Si `self.enable_multisource_fusion == False`:
1. El motor **no instancia** `MultisourceArbitrator` ni `EvidenceBundleManager` en memoria, reduciendo a cero el footprint computacional.
2. La llamada a `retrieve()` ejecuta su flujo RRF canónico preexistente y **no añade ninguna clave invasiva** en el cuerpo de la respuesta principal (`status`, `query`, `evidence`, `related_passages` permanecen 100% idénticos e invariantes bit a bit).
3. Si `enable_shadow_mode_multisource == True`, se mantiene el registro pasivo en el log JSONL desacoplado de Fase 4.2.3.
4. Si `enable_multisource_fusion == True`, la estructura `EvidenceBundle` serializada se adjunta **exclusivamente bajo la clave opcional `metadata['evidence_bundle']`**, preservando intacto el contrato de `evidence` primaria.

---

## 5. Módulo `NormativeGuard`: Formalización de Proposiciones y Arbitraje Deóntico (H-426-V26-01)

### 5.1 Erradicación Total de Heurísticas Residuales
Se eliminan **completamente** todas las comprobaciones de subcadenas léxicas (ej. `bridge in q_lower`, `involuntario in sc_text`), inspecciones por mención incidental de números de artículos (ej. `"14" in primary_articles`) o simulaciones de parsers universales.

`NormativeGuard` opera **exclusivamente sobre proposiciones normativas estructuradas (`NormativeProposition`)** asociadas a cada evidencia recuperada.

### 5.2 Política Estricta de No Admisión de Sidecars No Estructurados
- **Regla Inflexible:** Todo fragmento Sidecar que ingrese al motor de arbitraje **debe poseer una proposición estructurada (`sc.proposition is not None`)** validada en el momento de la ingesta.
- **Consecuencia de Ausencia de Estructura:** Si un fragmento complementario carece de proposición estructurada formal (`sc.proposition is None`), se considera técnicamente no deliberable. `NormativeGuard` lo rechaza de inmediato con causa `UNSTRUCTURED_SIDECAR_INADMISSIBLE` y emite `action_taken = GuardActionTaken.CONSERVATIVE_FALLBACK` (o `PURGE_EXCEPTIONS`), impidiendo de raíz cualquier compromiso o riesgo de alucinación interpretativa.

### 5.3 Proposiciones Canónicas Protegidas del SOR 2026
El catálogo canónico se indexa formalmente por clave unívoca y se vincula de forma precisa con el dominio de la acción:

```python
CANONICAL_PROTECTED_PROPOSITIONS: Dict[str, NormativeProposition] = {
    "PROP-CAN-01-BRIDGE": NormativeProposition(
        subject="uke",
        action="head_bridge_landing",
        deontic_operator=DeonticOperator.PROHIBITION,
        target_object="tatami_landing_escape",
        conditions=["thrown_by_tori", "voluntary_bridge_attempt"],
        exceptions=[],  # CERO excepciones en aterrizaje sobre puente
        scope=ScopeApplicability(AgeCategory.ALL_AGES, CompetitionType.WORLD_JUDO_TOUR, "ALL", "SOR-2026"),
        sanction=NormativeSanction.IPPON,
        authority_tier=AuthorityTier.TIER_1_CANONICAL,
        document_ref="IJF SOR 2026",
        article_ref="14"
    ),
    "PROP-CAN-02-CADET-REVERSE": NormativeProposition(
        subject="tori",
        action="reverse_seoi_nage",
        deontic_operator=DeonticOperator.PROHIBITION,
        target_object="opponent_lapel_turn",
        conditions=["cadet_competition"],
        exceptions=[],  # Prohibición absoluta en Cadetes
        scope=ScopeApplicability(AgeCategory.CADET, CompetitionType.WORLD_JUDO_TOUR, "ALL", "SOR-2026", cadet_junior_excluded=True),
        sanction=NormativeSanction.SHIDO,
        authority_tier=AuthorityTier.TIER_1_CANONICAL,
        document_ref="IJF SOR 2026",
        article_ref="18.1.4"
    ),
    "PROP-CAN-03-KANSETSU-NON-ELBOW": NormativeProposition(
        subject="tori",
        action="kansetsu_waza_non_elbow",
        deontic_operator=DeonticOperator.PROHIBITION,
        target_object="joints_other_than_elbow",
        conditions=["ne_waza_or_tachi_waza"],
        exceptions=[],  # CERO excepciones fuera del codo
        scope=ScopeApplicability(AgeCategory.ALL_AGES, CompetitionType.WORLD_JUDO_TOUR, "ALL", "SOR-2026"),
        sanction=NormativeSanction.HANSOKU_MAKE_DIRECT,
        authority_tier=AuthorityTier.TIER_1_CANONICAL,
        document_ref="IJF SOR 2026",
        article_ref="18.2.1"
    ),
    "PROP-CAN-04-BELT-SKIRT-CHOKE": NormativeProposition(
        subject="tori",
        action="choke_using_belt_or_jacket_bottom",
        deontic_operator=DeonticOperator.PROHIBITION,
        target_object="opponent_neck",
        conditions=["encircling_or_direct_fabric"],
        exceptions=[],
        scope=ScopeApplicability(AgeCategory.ALL_AGES, CompetitionType.WORLD_JUDO_TOUR, "ALL", "SOR-2026"),
        sanction=NormativeSanction.SHIDO,
        authority_tier=AuthorityTier.TIER_1_CANONICAL,
        document_ref="IJF SOR 2026",
        article_ref="18.1.2"
    )
}
```

### 5.4 Algoritmo de Comparación Estructural Componente a Componente
La comparación formal entre la proposición canónica activa $\mathcal{P}_{\text{can}}$ y la proposición complementaria $\mathcal{P}_{\text{sc}}$ evalúa sistemáticamente los 9 componentes:

1. **Correspondencia de Acción y Objeto:** Si $\mathcal{P}_{\text{sc}}.\text{action} == \mathcal{P}_{\text{can}}.\text{action}$ y $\mathcal{P}_{\text{sc}}.\text{target\_object} == \mathcal{P}_{\text{can}}.\text{target\_object}$, se activa la deliberación deóntica.
2. **Incompatibilidad Deóntica:** Si $\mathcal{P}_{\text{can}}.\text{deontic\_operator} == \text{PROHIBITION}$ y $\mathcal{P}_{\text{sc}}.\text{deontic\_operator} \in \{\text{PERMISSION}, \text{EXCEPTION}\}$:
   - **Juicio:** Violación `CRITICAL` por intento de introducir excepciones ilícitas a una norma prohibitiva canónica.
3. **Dilución de Sanción:** Si $\mathcal{P}_{\text{can}}.\text{sanction} == \text{HANSOKU\_MAKE\_DIRECT}$ y $\mathcal{P}_{\text{sc}}.\text{sanction} \in \{\text{SHIDO}, \text{NO\_SANCTION}\}$:
   - **Juicio:** Violación `CRITICAL` por atenuación ilícita de sanción de descalificación en seguridad.
4. **Colisión de Alcance por Edad:** Si $\mathcal{P}_{\text{can}}.\text{scope}.\text{age\_category} == \text{CADET}$ y $\mathcal{P}_{\text{sc}}.\text{scope}.\text{cadet\_junior\_excluded} == \text{True}$ pretendiendo validar la técnica para Cadetes:
   - **Juicio:** Violación `CRITICAL` por extrapolación ilegal de categoría Senior a formativa protegida.
5. **Colisión de Jerarquía de Autoridad:** Si $\mathcal{P}_{\text{sc}}.\text{authority\_tier}$ es inferior a Tier 2 e intenta modificar una regla imperativa:
   - **Juicio:** Violación `CRITICAL` por usurpación de competencia normativa.
6. **Abstención Conservadora Obligatoria:** Ante proposiciones con acciones no catalogadas en la matriz canónica, condiciones desconocidas o ambigüedad estructural:
   - **Juicio:** Se activa `GuardActionTaken.CONSERVATIVE_FALLBACK`, se rechaza el Sidecar y se mantiene exclusivamente la evidencia canónica primaria.

```python
class NormativeGuard:
    PROTECTED_PROPOSITIONS = CANONICAL_PROTECTED_PROPOSITIONS

    @classmethod
    def find_applicable_canonical_proposition(cls, primary_items: List[EvidenceItem]) -> Optional[NormativeProposition]:
        """Identificación inequívoca de la proposición canónica activa basada en estructura formal (H-426-V26-01)."""
        for p in primary_items:
            if p.proposition is not None:
                for can_prop in cls.PROTECTED_PROPOSITIONS.values():
                    if p.proposition.action == can_prop.action and p.proposition.target_object == can_prop.target_object:
                        return can_prop
        return None

    @classmethod
    def evaluate_decision(
        cls,
        query: str,
        primary_items: List[EvidenceItem],
        candidate_sidecars: List[EvidenceItem]
    ) -> NormativeGuardResult:
        retained: List[EvidenceItem] = []
        rejected: List[EvidenceItem] = []
        violations: List[GuardViolation] = []
        log: List[str] = []

        active_canonical = cls.find_applicable_canonical_proposition(primary_items)

        for sc in candidate_sidecars:
            sc_prop = sc.proposition

            # 1. Política de No Admisión de Sidecars sin Estructuración (H-426-V26-01)
            if sc_prop is None:
                sc.lifecycle_state = EvidenceLifecycleState.REJECTED
                sc.rejection_reason = "UNSTRUCTURED_SIDECAR_INADMISSIBLE"
                rejected.append(sc)
                violations.append(GuardViolation(
                    rule_id="RULE-SEC-UNSTRUCTURED",
                    severity=ViolationSeverity.CRITICAL,
                    article_id=sc.article_id,
                    description="Rechazo forzoso: Sidecar carece de proposición normativa estructurada formal.",
                    rejected_evidence_id=sc.evidence_id
                ))
                log.append(f"Rejected candidate {sc.evidence_id}: Lack of structured normative proposition.")
                continue

            # 2. Comparación Estructural contra Proposición Canónica Activa
            is_blocked = False

            if active_canonical is not None:
                # Comprobación de acción y objeto
                if sc_prop.action == active_canonical.action and sc_prop.target_object == active_canonical.target_object:
                    # Incompatibilidad Deóntica (Excepción sobre Prohibición)
                    if active_canonical.deontic_operator == DeonticOperator.PROHIBITION and sc_prop.deontic_operator in {DeonticOperator.PERMISSION, DeonticOperator.EXCEPTION}:
                        is_blocked = True
                        violations.append(GuardViolation(
                            rule_id="RULE-SEC-DEONTIC-CONFLICT",
                            severity=ViolationSeverity.CRITICAL,
                            article_id=sc.article_id,
                            description=f"Incompatibilidad deóntica: Intento ilícito de inyectar {sc_prop.deontic_operator.value} sobre prohibición canónica.",
                            rejected_evidence_id=sc.evidence_id
                        ))
                    
                    # Dilución de Sanción
                    if active_canonical.sanction == NormativeSanction.HANSOKU_MAKE_DIRECT and sc_prop.sanction != NormativeSanction.HANSOKU_MAKE_DIRECT:
                        is_blocked = True
                        violations.append(GuardViolation(
                            rule_id="RULE-SEC-SANCTION-DILUTION",
                            severity=ViolationSeverity.CRITICAL,
                            article_id=sc.article_id,
                            description="Dilución de sanción: Intento de atenuar descalificación directa (Hansoku-make) a sanción menor.",
                            rejected_evidence_id=sc.evidence_id
                        ))

                    # Conflicto de Alcance por Edad
                    if active_canonical.scope.age_category == AgeCategory.CADET and sc_prop.scope.cadet_junior_excluded:
                        is_blocked = True
                        violations.append(GuardViolation(
                            rule_id="RULE-SEC-SCOPE-CONFLICT",
                            severity=ViolationSeverity.CRITICAL,
                            article_id=sc.article_id,
                            description="Conflicto de alcance: Extrapolación ilícita de autorización Senior a categoría Cadetes.",
                            rejected_evidence_id=sc.evidence_id
                        ))

            if is_blocked:
                sc.lifecycle_state = EvidenceLifecycleState.REJECTED
                sc.rejection_reason = "GUARD_SECURITY_VIOLATION"
                rejected.append(sc)
                log.append(f"Rejected candidate {sc.evidence_id} due to CRITICAL deóntic violation.")
            else:
                retained.append(sc)
                log.append(f"Retained candidate {sc.evidence_id} (passed structural deóntic comparison).")

        critical_count = len([v for v in violations if v.severity == ViolationSeverity.CRITICAL])
        passed = (critical_count == 0)
        
        if passed:
            action = GuardActionTaken.PERMIT if not rejected else GuardActionTaken.PURGE_EXCEPTIONS
        else:
            action = GuardActionTaken.PURGE_EXCEPTIONS if retained else GuardActionTaken.BLOCK_ALL_SIDECAR

        return NormativeGuardResult(
            passed=passed,
            retained_sidecars=retained,
            rejected_sidecars=rejected,
            violations=violations,
            evaluation_log=log,
            action_taken=action
        )
```

---

## 6. Secuencia Incremental de Implementación y Baseline de Tests

```
Línea Base Certificada (267 tests PASSED)
   │
   ▼
[Etapa 1: Modelos de Datos, Provenance Formal y NormativeGuard Aislado]
   ├── Implementar src/evidence_bundle.py (Dataclasses, invariantes exhaustivos, hash completo)
   ├── Implementar src/normative_guard.py (Pipeline de 4 etapas, proposiciones y severidad)
   ├── Implementar tests/test_evidence_bundle.py (+5 tests: Invariantes, hash completo, suficiencia)
   ├── Implementar tests/test_normative_guard.py (+5 tests: Reglas deónticas, oráculos SEC-CRIT)
   └── Meta Etapa 1: 277 tests PASSED (267 base + 10 nuevos)
       └── Gate 1: pytest 277/277 sin errores.
   │
   ▼
[Etapa 2: Motor de Arbitraje Desacoplado]
   ├── Implementar src/multisource_arbitrator.py (Precedencia, vigencia y suficiencia probatoria)
   ├── Implementar tests/test_multisource_arbitrator.py (+5 tests)
   └── Meta Etapa 2: 282 tests PASSED (277 previos + 5 nuevos)
       └── Gate 2: pytest 282/282 sin errores.
   │
   ▼
[Etapa 3: Integración en RRE Engine con Feature Flag Tri-Estado]
   ├── Modificar src/rre_engine.py (Precedencia tri-estado, fallback desacoplado, metadata)
   ├── Implementar tests/test_fusion_invariance_ada.py (+4 tests: FF, Invarianza RRE, Invarianza ADA, Edad Desconocida)
   └── Meta Etapa 3: 286 tests PASSED (282 previos + 4 nuevos)
       └── Gate 3: Invarianza discreta 100.0%, delta flotante < 10^-4, pytest 286/286.
   │
   ▼
[Etapa 4: Ejecución del Dataset Hold-Out Reservado y Auditoría Final]
   ├── Ejecutar Dataset B hold-out reservado (20 casos de validación independiente)
   ├── Evaluar individualmente los 4 Casos Críticos de Seguridad (Zero-Tolerance: 4/4 PASS estricto)
   ├── Recalcular y validar los 6 hashes SHA-256 de archivos físicos protegidos
   └── Meta Etapa 4: >= 286 tests PASSED + Dataset B certificado
       └── Gate 4: Dictamen final de ChatGPT y firma soberana de Alexis Oliveros Lozano.
```

---

## 7. Protocolo de Rollback Seguro con Auditoría de Modificaciones (H-426-V26-03)

Se prohíbe taxativamente `os.remove()` o cualquier eliminación permanente. Se establece un protocolo basado en inventario real previo, verificación de hash antes y después, y aislamiento de archivos en directorios versionados sin colisiones:

```python
"""
Script de Rollback Seguro y Auditable — Fase 4.2.6 (H-426-V26-03)
Ubicación: scratch/rollback_fase4_2_6.py
"""
import os
import shutil
import time
import hashlib
import json

SNAPSHOT_PATH = "scratch/pre_fase4_2_6_snapshot/rre_engine.py.snapshot"
EXPECTED_SHA256 = "d45c17d3397427d6be2d2c379764a27439c5f7401538947c23c5fbd6c6ffae1e"
TARGET_RRE = "src/rre_engine.py"

PHASE_FILES_CREATED = [
    "src/evidence_bundle.py",
    "src/normative_guard.py",
    "src/multisource_arbitrator.py",
    "tests/test_evidence_bundle.py",
    "tests/test_normative_guard.py",
    "tests/test_multisource_arbitrator.py",
    "tests/test_fusion_invariance_ada.py"
]

def calculate_sha256(filepath: str) -> str:
    with open(filepath, "rb") as f:
        return hashlib.sha256(f.read()).hexdigest()

def execute_safe_rollback():
    ts = int(time.time())
    backup_dir = f"scratch/rollback_fase4_2_6/{ts}"
    os.makedirs(backup_dir, exist_ok=True)
    audit_log = []

    # 1. Precondición 1: Comprobar existencia y hash exacto del snapshot de respaldo
    if not os.path.exists(SNAPSHOT_PATH):
        raise FileNotFoundError(f"[ABORT] Snapshot previo no encontrado en {SNAPSHOT_PATH}")
    
    snap_hash = calculate_sha256(SNAPSHOT_PATH)
    if snap_hash != EXPECTED_SHA256:
        raise ValueError(f"[ABORT] Discrepancia en snapshot: {snap_hash} != {EXPECTED_SHA256}")
    audit_log.append(f"PRECHECK OK: Snapshot certificado verificado ({snap_hash})")

    # 2. Precondición 2: Inventario real previo de archivos creados en la fase
    existing_phase_files = [fp for fp in PHASE_FILES_CREATED if os.path.exists(fp)]
    audit_log.append(f"INVENTORY: {len(existing_phase_files)} archivos de fase detectados para aislamiento.")

    # 3. Traslado seguro (no destructivo) a directorio de backup único sin colisiones
    for fp in existing_phase_files:
        dest_filename = fp.replace("/", "_").replace("\\", "_")
        dest_path = os.path.join(backup_dir, dest_filename)
        # Copiar antes de desplazar
        shutil.copy2(fp, dest_path)
        # Comprobar integridad de la copia antes de retirar del árbol activo
        if calculate_sha256(dest_path) != calculate_sha256(fp):
            raise IOError(f"[ABORT] Fallo al verificar copia de respaldo para {fp}")
        # Desplazar a directorio de cuarentena (NUNCA os.remove)
        quarantine_dir = os.path.join(backup_dir, "quarantine")
        os.makedirs(quarantine_dir, exist_ok=True)
        shutil.move(fp, os.path.join(quarantine_dir, dest_filename))
        audit_log.append(f"ISOLATED: {fp} desplazado de forma segura a {dest_path}")

    # 4. Restauración selectiva y validada de src/rre_engine.py
    shutil.copy2(SNAPSHOT_PATH, TARGET_RRE)
    restored_hash = calculate_sha256(TARGET_RRE)
    if restored_hash != EXPECTED_SHA256:
        raise ValueError(f"[ABORT] Fallo de integridad en restauración: {restored_hash} != {EXPECTED_SHA256}")
    audit_log.append(f"RESTORED: {TARGET_RRE} verificado contra hash oficial ({restored_hash})")

    # 5. Registro final auditable
    with open(os.path.join(backup_dir, "audit_trail.json"), "w", encoding="utf-8") as f:
        json.dump({"timestamp": ts, "log": audit_log, "status": "COMPLETED_SAFELY"}, f, indent=2)

    print(f"[ROLLBACK SEGURO Y VERIFICADO COMPLETADO] Log en {backup_dir}")

if __name__ == "__main__":
    execute_safe_rollback()
```

---

## 8. Custodia e Independencia del Dataset B (Hold-Out Reservado) (H-426-V24-02)

1. **Terminología Formal:** Se denomina formalmente **«conjunto de validación hold-out reservado»** (*reserved hold-out set*).
2. **Ubicación y Formato:** `docs/benchmark_dataset_b_certificacion_ijf.json`.
3. **Custodia y Entrega Controlada:** Supervisado por Alexis Oliveros Lozano y auditado independientemente por ChatGPT. El archivo se mantiene inmutable y sellado antes de la Etapa 1.
4. **Mecanismo de Aislamiento Técnico:** Prohibición estricta de importación o lectura en módulos de `src/` o pruebas unitarias de `tests/`. Solo se cargará en memoria por el arnés en la Etapa 4 (`scratch/run_fase4_2_6_certification.py`).
5. **Limitaciones Metodológicas Declaradas:** Constituye un muestreo focalizado de seguridad y contención de riesgos (20 casos), no una certificación matemática exhaustiva de la totalidad del reglamento IJF.

---

## 9. Oráculos Exactos de los 4 Casos Críticos de Seguridad (H-426-V24-05)

Todos los oráculos se fundamentan textualmente en la edición canónica SOR 2026 oficial (agosto 2026) y circulares ejecutivas ratificadas:

| ID Caso | Consulta Exacta | Categoría y Contexto | Cita Normativa Exacta SOR 2026 | Mandato Canónico Imperativo | Sanción / Decisión Oficial | Comportamiento Requerido de `NormativeGuard` | Criterio de Éxito |
| :--- | :--- | :--- | :--- | :--- | :--- | :--- | :--- |
| `SEC-CRIT-01` | Si tori proyecta y uke cae sobre su puente de cuello voluntario para no marcar punto, ¿aplica excepción de contacto involuntario? | Seguridad / Caída cefálica | **Art. 14 (Ippon), pág. 166-167:** *«2. All situations in which one of the athletes voluntarily makes a “bridge” (head and one foot or both feet in contact with the tatami) after having been thrown will be ippon [...] This decision is taken for the safety of the athletes, so they do not try to escape from the technique and endanger their cervical spine.»* | Prohibición absoluta de usar puente de cuello para evadir puntuación. | **Ippon en contra.** | Purga absoluta de cualquier alegato de excepción o contacto involuntario (`GUARD_REJECTION`). Emite bundle `CANONICAL_EXCLUSIVE`. | **PASS:** Ippon confirmado; cero excepciones admitidas. |
| `SEC-CRIT-02` | ¿Puede un competidor cadete ejecutar reverse seoi-nage si asegura agarre cruzado? | Incompatibilidad de Alcance (Edad) | **Art. 18.1.4 (Shido in Cadet Competitions), pág. 189, pto. 35:** *«In cadet events there will be no score for reverse seoi-nage and TORI will be penalised with shido.»*<br>Circular KUN-NEW-001 (Senior). | Reverse seoi-nage prohibido en categoría Cadetes independientemente del agarre. | **No puntuación + Shido a Tori.** | Detección de incompatibilidad en `ScopeApplicability`. Bloquea autorización Senior. Activa `requires_context_disambiguation` o prohibición Cadetes. | **PASS:** Prohibición en Cadetes confirmada; cero extrapolaciones erróneas. |
| `SEC-CRIT-03` | En ne-waza, ¿es legal aplicar palanca articular sobre la rodilla si la acción inició en pie? | Seguridad / Acciones Prohibidas Directas | **Art. 18.2.1 / 18.2.2 (Grave Infringements), pág. 191, pto. 4:** *«To apply kansetsu-waza to any joint other than the elbow joint (e.g., ashi-garami). [...] will be penalised with hansoku-make.»* | Prohibición absoluta de llaves articulares sobre articulaciones distintas del codo. | **Hansoku-make directo** (Descalificación). | Bloqueo inmediato de interpretaciones permisivas (`GUARD_REJECTION`). Bundling exclusivo de Art. 18.2. | **PASS:** Hansoku-make directo ratificado sin atenuantes. |
| `SEC-CRIT-04` | ¿Es legal estrangular al oponente utilizando directamente la pretina o faldón del propio cinturón desatado? | Infracciones de Vestimenta / Movimientos Ilegales | **Art. 18.1.2 (Shido for an Illegal Move), pág. 184-185, ptos. 20 y 23:** *«20. To encircle the end of the belt or jacket around any part of the opponent’s body [...] 23. To apply shime-waza using either your own or your opponent’s belt or bottom of the jacket»* | Prohibición de estrangular con la pretina, extremo de cinturón o faldón de chaqueta. | **Shido.** | Bloqueo de fragmentos que sugieran validez. Ratificación de infracción con Shido. | **PASS:** Shido confirmado; técnica clasificada como ilegal. |

> [!NOTE]
> Las respuestas esperadas no constituyen un resultado favorable pre-aprobado sino los **oráculos objetivos** contra los cuales el arnés automatizado de certificación evaluará de manera inexorable el comportamiento de la implementación en la Etapa 4.

---

## 10. Reconciliación de Invarianza: Discreta vs Numérica (H-426-V24-01 / V23-06)

1. **Invarianza Discreta Estricta (Tolerancia 0.0% / Igualdad Exacta de Cadenas y Conjuntos):**
   - Identificadores de pasajes primarios (`passage_id`) y su ordenamiento secuencial exacto.
   - Cantidad de evidencias primarias (`len(evidence_list)`).
   - Artículos canónicos citados (`article_id`).
   - Estado de respuesta (`status == "SUCCESS"` / `"ABSTAIN"`).
2. **Invarianza Numérica en Puntuaciones Primarias (Tolerancia Flotante de Precisión):**
   - Los scores flotantes primarios generados por el algoritmo RRF (`score`) deben ser idénticos con una tolerancia estricta:
     $$|\text{score}_{\text{baseline}} - \text{score}_{\text{fusion}}| < 10^{-4}$$
   - Esta tolerancia atiende a variaciones microscópicas de representación en coma flotante IEEE 754 entre compilaciones de Python y librerías numéricas, garantizando que el orden relativo permanezca matemáticamente inalterado.

---

## 11. Metodología de Medición de Latencia y Overhead

1. **Instrumentación de Alta Resolución:** Uso exclusivo de `time.perf_counter()` para medir tiempos en milisegundos.
2. **Protocolo Experimental:**
   - 1 ciclo de calentamiento (*warm-up*) de 5 consultas no contabilizadas para estabilizar caché de memoria.
   - 3 ejecuciones consecutivas independientes sobre el benchmark de 40 consultas.
   - Cálculo de métricas agregadas: Media, Mediana, Percentil 95 (P95) y Desviación Estándar.
3. **Umbrales Máximos Aceptables:**
   - Overhead de la etapa de arbitraje en memoria: $\Delta_{\text{mean}} \le 5.0\text{ ms}$.
   - Latencia total del RRE en modo fusión: $P95 \le 80.0\text{ ms}$.

---

## 12. Protocolo de Auditoría y Gobernanza Tripartita

Se formaliza la separación de roles y responsabilidades en tres niveles independientes:

1. **Revisión Técnica y Ejecución (Antigravity):**
   - Ejecuta las tareas autorizadas de la etapa en modo estrictamente secuencial.
   - Genera los informes técnicos autocontenidos, evidencias reproducibles y tablas de hashes.
   - No tiene atribución de declarar aprobación ni certificar sus propios entregables.
2. **Auditoría Arquitectónica Independiente (ChatGPT):**
   - Examina el código, los diffs de Git, los logs de pytest y el cumplimiento de invariantes.
   - Emite el dictamen técnico formal: **CONFORME**, **CON OBSERVACIONES** o **NO CONFORME**.
3. **Autoridad Soberana de Aprobación (Alexis Oliveros Lozano):**
   - Evalúa el dictamen de ChatGPT y los informes de Antigravity.
   - Emite la autorización formal, expresa y bloqueante para iniciar la siguiente etapa o activar flags.

---

## 13. Matriz de Autorizaciones para Futura Ejecución

| Actividad Operacional | Autoridad Responsable | Condición Previa Requerida | Estado Actual |
| :--- | :--- | :--- | :--- |
| **Preparación Documental Plan Maestro v2.7** | Alexis Oliveros Lozano | Aprobación de diseño v2.2 | **AUTORIZADO / COMPLETADO** |
| **Implementación de Código (Etapas 1 y 2)**| Alexis Oliveros Lozano | Dictamen favorable de ChatGPT sobre Plan Maestro v2.7 | **PENDIENTE DE AUTORIZACIÓN** |
| **Integración en RRE (Etapa 3)** | Alexis Oliveros Lozano | Aprobación formal de Etapas 1 y 2 | **NO AUTORIZADO** |
| **Ejecución de Certificación (Etapa 4)**| Alexis Oliveros Lozano | Aprobación formal de Etapa 3 | **NO AUTORIZADO** |
| **Operaciones Git Remotas (Push/Merge)**| Alexis Oliveros Lozano | Certificación final y cierre de fase | **ESTRICTAMENTE PROHIBIDO** |
| **Despliegue OCI / Producción** | Alexis Oliveros Lozano | Cierre total de Fase 4 y auditoría externa | **ESTRICTAMENTE PROHIBIDO** |
