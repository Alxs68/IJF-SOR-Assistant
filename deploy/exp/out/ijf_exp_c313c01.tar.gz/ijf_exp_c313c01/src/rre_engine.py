"""
Reasoning Retrieval Engine (RRE) for IJF-SOR-Assistant
======================================================
Official Normative Corpus: IJF Sport and Organisation Rules (14 August 2026)

Key Architectural Pillars:
1. Dense Semantic Embeddings: 384-dimensional dense vectors (all-MiniLM-L6-v2) cached locally.
2. Sparse Lexical Scoring: Normalized exact term and phrase matching with normative stopword filtering.
3. Reciprocal Rank Fusion (RRF): Robust rank combination prioritizing evidence present in both channels.
4. Knowledge Graph Expansion: Context enrichment along verified cross-reference edges (112 edges).
5. Strict Abstention Filter: Immediate rejection of out-of-domain or ungrounded queries.
"""

import os
import re
import json
import math
from typing import List, Dict, Any, Optional
import numpy as np
from collections import Counter
import glob

from src.normative_ontology import NormativeOntology, NormativeDomain
from src.passage_stitcher import PassageStitcher
from src.referee_command_disambiguator import RefereeCommandDisambiguator
from src.normative_semantic_ranker import NormativeSemanticRanker
from src.ood_detector import OODDetector
from src.negative_domain_anchor_scoring import NegativeDomainAnchorScorer, NegativeDomainResult

# Domain-specific stopwords (English & Spanish functional words)
STOPWORDS = {
    "de", "la", "el", "en", "y", "a", "los", "las", "un", "una", "por", "con", "para", "o",
    "the", "of", "and", "in", "to", "is", "for", "on", "by", "with", "at", "as", "from", "an",
    "how", "what", "when", "where", "why", "who", "which", "can", "could", "would", "should",
    "que", "cual", "cuales", "como", "donde", "cuando", "quien", "quienes",
    "se", "su", "sus", "del", "al", "formula", "son", "ocurre", "si", "durante", "corresponde", "accion", "acciones"
}

class ReasoningRetrievalEngine:
    """
    RRE: High-precision hybrid neural-lexical retriever with graph expansion
    designed for arbitration and regulatory rules.
    """

    def __init__(self, base_dir="data/processed/rebuild_2026_08_corrected", allow_degraded: bool | None = None, enable_code_matching: bool = True, enable_chunk_stitching: bool | None = None, max_expansion_pages: int = 3, enable_semantic_ranker: bool = False, enable_referee_disambiguation: bool = False, enable_ood_detector: bool = False, enable_negative_domain_anchors: bool = False, shadow_mode_negative_anchors: bool = False, enable_shadow_mode_multisource: bool = False, shadow_log_path: str = "scratch/shadow_multisource_evaluation.jsonl", enable_scope_preference: bool | None = None):
        self.base_dir = base_dir
        if allow_degraded is None:
            allow_degraded = os.environ.get("RRE_ALLOW_DEGRADED_LEXICAL", "").strip().lower() in {"1", "true", "yes", "on"}
        self.allow_degraded = bool(allow_degraded)
        self.enable_code_matching = enable_code_matching        # Feature flag: Chunk Stitching (activado por defecto en arquitectura Lean, desactivable explícitamente)
        if enable_chunk_stitching is None:
            env_val = os.environ.get("RRE_ENABLE_CHUNK_STITCHING", "").strip().lower()
            if env_val in {"0", "false", "no", "off"}:
                enable_chunk_stitching = False
            else:
                enable_chunk_stitching = True
        self.enable_chunk_stitching = bool(enable_chunk_stitching)
        self.max_expansion_pages = max_expansion_pages

        # Feature flags Fase 3: RRE 3.0 (desactivados por defecto)
        if not enable_semantic_ranker:
            enable_semantic_ranker = os.environ.get("RRE_ENABLE_SEMANTIC_RANKER", "").strip().lower() in {"1", "true", "yes", "on"}
        self.enable_semantic_ranker = bool(enable_semantic_ranker)

        if not enable_referee_disambiguation:
            enable_referee_disambiguation = os.environ.get("RRE_ENABLE_REFEREE_DISAMBIGUATION", "").strip().lower() in {"1", "true", "yes", "on"}
        self.enable_referee_disambiguation = bool(enable_referee_disambiguation)

        if not enable_ood_detector:
            enable_ood_detector = os.environ.get("RRE_ENABLE_OOD_DETECTOR", "").strip().lower() in {"1", "true", "yes", "on"}
        self.enable_ood_detector = bool(enable_ood_detector)

        # Feature flags Fase 4.2.1: BK-01 Negative Domain Anchors (desactivados por defecto)
        if not enable_negative_domain_anchors:
            enable_negative_domain_anchors = os.environ.get("RRE_ENABLE_NEGATIVE_DOMAIN_ANCHORS", "").strip().lower() in {"1", "true", "yes", "on"}
        self.enable_negative_domain_anchors = bool(enable_negative_domain_anchors)

        if not shadow_mode_negative_anchors:
            shadow_mode_negative_anchors = os.environ.get("RRE_SHADOW_MODE_NEGATIVE_ANCHORS", "").strip().lower() in {"1", "true", "yes", "on"}
        self.shadow_mode_negative_anchors = bool(shadow_mode_negative_anchors)

        # Feature flag Fase 4.2.3: Multisource Sidecar Shadow Mode (desactivado por defecto)
        if not enable_shadow_mode_multisource:
            enable_shadow_mode_multisource = os.environ.get("RRE_ENABLE_SHADOW_MODE_MULTISOURCE", "").strip().lower() in {"1", "true", "yes", "on"}
        self.enable_shadow_mode_multisource = bool(enable_shadow_mode_multisource)
        self.shadow_log_path = shadow_log_path
        self.sidecar_retriever = None
        self.last_shadow_result = None

        self.passages_file = os.path.join(base_dir, "passages_candidate.json")
        self.graph_file = os.path.join(base_dir, "knowledge_graph_candidate.json")
        self.sparse_index_file = os.path.join(base_dir, "vector_index_candidate.json")
        self.dense_embeddings_file = os.path.join(base_dir, "dense_embeddings_candidate.npy")
        self.dense_meta_file = os.path.join(base_dir, "dense_embeddings_meta.json")

        self.passages = []
        self.passages_by_id = {}
        self.graph_edges = []
        self.graph_adj = {}  # pid -> list of target pids
        self.sparse_index = {}
        self.dense_embeddings = None
        self.dense_meta = {}
        self.dense_model = None
        self.operating_mode = "UNINITIALIZED"
        self.degradation_reason = None
        self.source_sha256_verified = False

        self._load_resources()
        self._validate_dense_matrix_and_meta()
        self._init_dense_model()
        self._determine_operating_mode()

        # Inicializar componentes Fase 3 si están habilitados
        self.stitcher = PassageStitcher(self.passages_by_id, max_expansion_pages=self.max_expansion_pages) if self.enable_chunk_stitching else None
        self.ood_detector = OODDetector(self.dense_model, self.dense_embeddings) if self.enable_ood_detector else None

        # Fase 11 - R3: preferencia por ambito (desactivada por defecto; RRE_ENABLE_SCOPE_PREFERENCE=1)
        from src.scope_preference import ScopePreference, flag_enabled
        self.enable_scope_preference = flag_enabled(enable_scope_preference)
        self.scope_preference = ScopePreference() if self.enable_scope_preference else None

        # Inicializar componente Sidecar Shadow Mode si está habilitado
        if self.enable_shadow_mode_multisource:
            self._init_sidecar_retriever()

        if not self.allow_degraded and self.operating_mode != "HYBRID":
            raise RuntimeError(
                f"Inicialización de RRE rechazada: Se requiere modo HYBRID pero el motor operaría en modo "
                f"'{self.operating_mode}' debido a: {self.degradation_reason}"
            )

    def _init_sidecar_retriever(self):
        """Inicializa el recuperador Sidecar con aislamiento total de errores."""
        try:
            from src.multisource_retriever import MultisourceRetriever
            self.sidecar_retriever = MultisourceRetriever()
        except Exception as e:
            # En caso de fallo de inicialización, no bloquear RRE
            self.sidecar_retriever = None


    def retrieve_supplementary(self, query: str, top_k: int = 3, min_score: float = 2.0) -> list:
        """Safely retrieves supplementary passages from multisource sidecar if available."""
        try:
            if self.sidecar_retriever is None:
                from src.multisource_retriever import MultisourceRetriever
                self.sidecar_retriever = MultisourceRetriever()
            res = self.sidecar_retriever.search(query, top_k=top_k, min_score=min_score)
            if res.get("status") == "SUCCESS":
                return res.get("matches", [])
        except Exception:
            pass
        return []

    def _execute_shadow_sidecar_retrieval(self, query: str, primary_evidence: List[Dict[str, Any]]) -> Dict[str, Any]:
        """
        Ejecuta la recuperación Sidecar en modo sombra.
        - Completamente aislado de la respuesta principal.
        - No modifica `primary_evidence`.
        - Registra el log de evaluación comparativa.
        """
        import time
        t0 = time.perf_counter()
        shadow_record = {
            "timestamp": time.time(),
            "query": query,
            "primary_top1_id": primary_evidence[0].get("passage_id") if primary_evidence else None,
            "primary_top1_article": primary_evidence[0].get("article_id") if primary_evidence else None,
            "primary_top1_score": primary_evidence[0].get("score") if primary_evidence else None,
            "sidecar_status": "DISABLED",
            "sidecar_matches": [],
            "sidecar_elapsed_ms": 0.0,
            "shadow_overhead_ms": 0.0
        }

        if not self.enable_shadow_mode_multisource:
            return shadow_record

        if self.sidecar_retriever is None:
            self._init_sidecar_retriever()

        if self.sidecar_retriever is None:
            shadow_record["sidecar_status"] = "INITIALIZATION_FAILED"
            self.last_shadow_result = shadow_record
            self._write_shadow_log(shadow_record)
            return shadow_record

        try:
            # Ejecutar búsqueda con timeout de seguridad (100ms)
            sidecar_res = self.sidecar_retriever.search(query, top_k=3, min_score=0.05, timeout_ms=100.0)
            shadow_record["sidecar_status"] = sidecar_res.get("status", "UNKNOWN")
            shadow_record["sidecar_elapsed_ms"] = sidecar_res.get("elapsed_ms", 0.0)
            shadow_record["sidecar_matches"] = sidecar_res.get("matches", [])
        except Exception as e:
            shadow_record["sidecar_status"] = f"ERROR: {type(e).__name__}: {str(e)}"

        overhead_ms = (time.perf_counter() - t0) * 1000.0
        shadow_record["shadow_overhead_ms"] = round(overhead_ms, 3)
        self.last_shadow_result = shadow_record
        self._write_shadow_log(shadow_record)
        return shadow_record

    def _write_shadow_log(self, record: Dict[str, Any]):
        """Escribe el registro de evaluación en el archivo de log con manejo seguro de concurrencia/fallos."""
        try:
            if not self.shadow_log_path:
                return
            log_dir = os.path.dirname(self.shadow_log_path)
            if log_dir and not os.path.exists(log_dir):
                os.makedirs(log_dir, exist_ok=True)
            with open(self.shadow_log_path, "a", encoding="utf-8") as f:
                f.write(json.dumps(record, ensure_ascii=False) + "\n")
        except Exception:
            # Jamás interrumpir el flujo del RRE por un fallo de escritura de log
            pass

    def _load_resources(self):
        if not os.path.exists(self.passages_file):
            raise FileNotFoundError(f"RRE passages file not found: {self.passages_file}")

        with open(self.passages_file, "r", encoding="utf-8") as f:
            self.passages = json.load(f)
        self.passages_by_id = {p["passage_id"]: p for p in self.passages}

        if os.path.exists(self.graph_file):
            with open(self.graph_file, "r", encoding="utf-8") as f:
                gdata = json.load(f)
                self.graph_edges = gdata.get("edges", [])
                for edge in self.graph_edges:
                    src = edge.get("source")
                    tgt = edge.get("target")
                    if src and tgt:
                        self.graph_adj.setdefault(src, []).append({
                            "target": tgt,
                            "relation": edge.get("relation_type", "references_article")
                        })

        if os.path.exists(self.sparse_index_file):
            with open(self.sparse_index_file, "r", encoding="utf-8") as f:
                self.sparse_index = json.load(f)

        if os.path.exists(self.dense_embeddings_file):
            try:
                self.dense_embeddings = np.load(self.dense_embeddings_file)
            except Exception as e:
                raise ValueError(f"Error crítico al leer la matriz densa {self.dense_embeddings_file}: {e}")

        if os.path.exists(self.dense_meta_file):
            with open(self.dense_meta_file, "r", encoding="utf-8") as f:
                self.dense_meta = json.load(f)

    def _validate_dense_matrix_and_meta(self):
        """
        Validación exhaustiva de integridad matemática y referencial de la matriz densa.
        Si la matriz o sus metadatos están presentes pero presentan cualquier corrupción o desalineación,
        se lanza un ValueError explícito y accionable.
        """
        if self.dense_embeddings is None and not self.dense_meta:
            # Matriz no provista en absoluto (degradación léxica permitida únicamente si se solicita explícitamente)
            return

        if self.dense_embeddings is None and self.dense_meta:
            raise ValueError(
                f"Inconsistencia crítica en RRE: Existen metadatos ({self.dense_meta_file}) "
                f"pero no se encontró el archivo de matriz densa ({self.dense_embeddings_file})."
            )

        if self.dense_embeddings is not None and not self.dense_meta:
            raise ValueError(
                f"Inconsistencia crítica en RRE: La matriz densa existe ({self.dense_embeddings_file}) "
                f"pero faltan sus metadatos de procedencia ({self.dense_meta_file})."
            )

        # 1. Validación de forma y número de pasajes
        expected_rows = len(self.passages)
        expected_dim = 384
        if not isinstance(self.dense_embeddings, np.ndarray):
            raise TypeError("La matriz densa debe ser una instancia válida de numpy.ndarray.")

        if len(self.dense_embeddings.shape) != 2:
            raise ValueError(
                f"Forma inválida en matriz densa: Se esperaban 2 dimensiones, se obtuvieron {self.dense_embeddings.ndim}."
            )

        n_rows, n_cols = self.dense_embeddings.shape
        if n_rows != expected_rows:
            raise ValueError(
                f"Discrepancia en número de pasajes: El corpus contiene {expected_rows} pasajes "
                f"pero la matriz densa contiene {n_rows} filas."
            )

        if n_cols != expected_dim:
            raise ValueError(
                f"Discrepancia dimensional: Dimensión del modelo esperada {expected_dim}, "
                f"pero la matriz densa tiene dimensión {n_cols}."
            )

        # 2. Valores finitos (sin NaNs ni Infs)
        if not np.all(np.isfinite(self.dense_embeddings)):
            nan_count = int(np.sum(np.isnan(self.dense_embeddings)))
            inf_count = int(np.sum(np.isinf(self.dense_embeddings)))
            raise ValueError(
                f"Matriz densa corrupta: Contiene valores no finitos ({nan_count} NaNs, {inf_count} Infs)."
            )

        # 3. Coherencia de Metadatos
        meta_num = self.dense_meta.get("num_passages")
        if meta_num != expected_rows:
            raise ValueError(
                f"Metadatos inconsistentes: 'num_passages'={meta_num} != pasajes del corpus={expected_rows}."
            )

        meta_dim = self.dense_meta.get("dimension")
        if meta_dim != expected_dim:
            raise ValueError(
                f"Metadatos inconsistentes: 'dimension'={meta_dim} != dimensión esperada={expected_dim}."
            )

        meta_model = self.dense_meta.get("model_name")
        if meta_model != "sentence-transformers/all-MiniLM-L6-v2":
            raise ValueError(
                f"Metadatos incompatibles: Modelo de origen declarado '{meta_model}', se requiere 'sentence-transformers/all-MiniLM-L6-v2'."
            )

        # 4. Verificación exhaustiva 1:1 de passage_ids (longitud, duplicados y orden)
        meta_ids = self.dense_meta.get("passage_ids", [])
        if len(meta_ids) != expected_rows:
            raise ValueError(
                f"Longitud de passage_ids en metadatos ({len(meta_ids)}) difiere del corpus ({expected_rows})."
            )

        if len(set(meta_ids)) != len(meta_ids):
            duplicates = [item for item, count in Counter(meta_ids).items() if count > 1]
            raise ValueError(f"Identificadores duplicados en passage_ids de metadatos: {duplicates[:5]}.")

        corpus_ids = [p["passage_id"] for p in self.passages]
        if meta_ids != corpus_ids:
            # Buscar el primer índice discordante para mensaje de error preciso
            for i, (m_id, c_id) in enumerate(zip(meta_ids, corpus_ids)):
                if m_id != c_id:
                    raise ValueError(
                        f"Desalineación en orden de pasajes en índice {i}: "
                        f"Metadatos='{m_id}' vs Corpus='{c_id}'."
                    )
            raise ValueError("La lista de passage_ids de metadatos no coincide exactamente con el orden del corpus.")

        # 5. Integridad del hash del corpus declarado frente a fuente de verdad
        expected_sha = "9426b10d11c21a4cb9eb23150c2c4fc95bfcd463511e66ba451d2cff005ae620"
        meta_sha = str(self.dense_meta.get("source_sha256", "")).lower()
        if meta_sha != expected_sha:
            raise ValueError(
                f"Discrepancia criptográfica en metadatos: source_sha256 declarado '{meta_sha}' "
                f"no coincide con la edición oficial SOR 2026-08 '{expected_sha}'."
            )

        # Comprobar si el PDF físico existe en disco para verificación efectiva
        pdf_candidate = os.path.join(os.path.dirname(os.path.dirname(self.base_dir)), "raw", "sor_2026_08_rebuild", "IJF_Sport_and_Organisation_Rules_2026_08_14.pdf")
        if os.path.exists(pdf_candidate):
            import hashlib
            h = hashlib.sha256()
            with open(pdf_candidate, "rb") as f:
                while chunk := f.read(65536):
                    h.update(chunk)
            real_sha = h.hexdigest().lower()
            if real_sha == expected_sha:
                self.source_sha256_verified = True
            else:
                raise ValueError(
                    f"Fallo de verificación criptográfica del PDF físico: SHA-256 calculado '{real_sha}' "
                    f"no coincide con el esperado '{expected_sha}'."
                )

    def _init_dense_model(self):
        """Load only an explicitly prepared local snapshot; never download during app startup."""
        configured_path = os.environ.get("RRE_MODEL_PATH", "").strip()
        candidates = []
        if configured_path:
            candidates.append(os.path.abspath(os.path.expanduser(configured_path)))

        cache_pattern = os.path.expanduser(
            "~/.cache/huggingface/hub/models--sentence-transformers--all-MiniLM-L6-v2/snapshots/*"
        )
        candidates.extend(sorted(glob.glob(cache_pattern), reverse=True))

        try:
            from sentence_transformers import SentenceTransformer
        except Exception as e:
            self.dense_model = None
            self.degradation_reason = f"No se pudo importar SentenceTransformer: {e}"
            return

        errors = []
        seen = set()
        for candidate in candidates:
            if candidate in seen or not os.path.isdir(candidate):
                continue
            seen.add(candidate)
            try:
                model = SentenceTransformer(candidate, local_files_only=True)
                dimension = model.get_sentence_embedding_dimension()
                if dimension != 384:
                    raise ValueError(
                        f"El modelo local devuelve dimensión {dimension}; se requieren 384."
                    )
                self.dense_model = model
                self.degradation_reason = None
                return
            except Exception as e:
                errors.append(f"{candidate}: {e}")

        self.dense_model = None
        self.degradation_reason = (
            "No se encontró un snapshot local verificado de "
            "sentence-transformers/all-MiniLM-L6-v2. Ejecute primero "
            "'python scripts/setup_model.py'."
        )
        if errors:
            self.degradation_reason += " Errores de carga local: " + " | ".join(errors[:2])

    def _determine_operating_mode(self):
        """Select HYBRID only when dense, sparse and graph resources are coherent."""
        expected_sha = "9426b10d11c21a4cb9eb23150c2c4fc95bfcd463511e66ba451d2cff005ae620"
        corpus_ids = set(self.passages_by_id)

        # The lexical channel must always be usable; without it, neither mode can retrieve.
        index = self.sparse_index
        idf = index.get("idf") if isinstance(index, dict) else None
        vectors = index.get("vectors") if isinstance(index, dict) else None
        if not isinstance(idf, dict) or not idf or not isinstance(vectors, dict) or not vectors:
            raise RuntimeError(
                f"Índice léxico TF-IDF ausente o inválido: {self.sparse_index_file}. "
                "Reconstruya el índice antes de iniciar RRE."
            )
        if index.get("num_docs") != len(self.passages):
            raise ValueError(
                f"Número de documentos del índice léxico ({index.get('num_docs')}) "
                f"no coincide con los pasajes ({len(self.passages)})."
            )
        if str(index.get("source_sha256", "")).lower() != expected_sha:
            raise ValueError("El índice léxico no declara el SHA-256 de la edición oficial SOR 2026-08.")
        if set(vectors) != corpus_ids:
            missing = sorted(corpus_ids - set(vectors))
            extra = sorted(set(vectors) - corpus_ids)
            raise ValueError(
                f"IDs del índice léxico incompatibles con el corpus. Faltantes: {missing[:3]}; "
                f"no reconocidos: {extra[:3]}."
            )
        for term, weight in idf.items():
            if not isinstance(term, str) or not isinstance(weight, (int, float)) or not math.isfinite(weight):
                raise ValueError("El índice léxico contiene pesos IDF no válidos.")
        for pid, vector in vectors.items():
            passage_text = self.passages_by_id.get(pid, {}).get("text_original", "").strip()
            if not isinstance(vector, dict) or (not vector and passage_text):
                raise ValueError(f"Vector léxico vacío o inválido para el pasaje {pid}.")
            if any(not isinstance(w, (int, float)) or not math.isfinite(w) for w in vector.values()):
                raise ValueError(f"El vector léxico del pasaje {pid} contiene pesos no válidos.")

        # A graph can be absent only in explicitly authorized lexical-degraded mode.
        graph_ok = bool(self.graph_edges)
        for edge in self.graph_edges:
            src = edge.get("source")
            tgt = edge.get("target")
            if src not in corpus_ids or tgt not in corpus_ids:
                raise ValueError(
                    f"El grafo normativo contiene una arista hacia/desde un pasaje inexistente: {src} -> {tgt}."
                )

        has_matrix = (
            isinstance(self.dense_embeddings, np.ndarray)
            and self.dense_embeddings.shape == (len(self.passages), 384)
        )
        has_model = self.dense_model is not None
        missing = []
        if not has_matrix:
            missing.append("matriz densa ausente")
        if not has_model:
            missing.append(self.degradation_reason or "modelo neuronal no disponible")
        if not graph_ok:
            missing.append("grafo normativo ausente o sin aristas válidas")

        if not missing:
            self.operating_mode = "HYBRID"
            self.degradation_reason = None
        else:
            self.operating_mode = "DEGRADED_LEXICAL"
            self.degradation_reason = "; ".join(missing)

    # Mapeo bilingüe de términos técnicos y normativos del judo
    SPANISH_TO_ENGLISH_SYNONYMS = {
        "cabeza": "head",
        "defensa": "defend defence",
        "defenderse": "defend defence",
        "defender": "defend defence",
        "defence": "defend defence",
        "defense": "defend defence",
        "clavado": "diving dive",
        "zambullida": "diving dive",
        "buceo": "diving dive",
        "puente": "bridge",
        "caer": "landing fall",
        "caida": "landing fall",
        "sancion": "penalty",
        "sanciones": "penalties",
        "sanciona": "penalty",
        "arbitro": "referee",
        "arbitraje": "refereeing",
        "pesaje": "weigh-in",
        "peso": "weight",
        "estrangulacion": "shime-waza",
        "estrangulaciones": "shime-waza",
        "luxacion": "kansetsu-waza",
        "luxaciones": "kansetsu-waza",
        "repesca": "repechage",
        "combate": "contest",
        "duracion": "duration",
        "tiempo": "time",
        "medico": "medical",
        "doctor": "doctor",
        "categoria": "category",
        "categorias": "categories",
        "cadetes": "cadet",
        "cadete": "cadet",
        "juniors": "junior",
        "seniors": "senior",
        "insulto": "derogatory remark remarks gesture spirit",
        "insultos": "derogatory remarks gestures spirit",
        "insulta": "derogatory remark remarks gesture spirit",
        "agresion": "aggression spirit deliberate injury",
        "agresión": "aggression spirit deliberate injury",
        "agrede": "aggression spirit deliberate injury",
        "agredio": "aggression spirit deliberate injury",
        "golpe": "strike punch kick deliberate injury spirit",
        "reverse": "reverse seoi-nage",
        "seoinage": "seoi-nage",
        "proyeccion": "throw",
        "proyecciones": "throw",
        "lanzamiento": "throw",
        "apoya": "head",
        "apoyar": "head",
        "apoyo": "head",
        "oro": "gold",
        "puntos": "points",
        "puntuacion": "scoring",
        "descalificacion": "disqualification",
        "descalificaciones": "disqualification",
        "directa": "direct",
        "directo": "direct",
        "sangra": "bleeding",
        "sangrado": "bleeding",
        "sangre": "blood",
        "hemorragia": "bleeding",
        "entrenador": "coach",
        "entrenadores": "coaches",
        "vestimenta": "dress code clothing attire",
        "veterano": "veteran",
        "veteranos": "veterans",
        "master": "veteran",
        "masters": "veterans",
        "antidopaje": "doping control anti-doping",
        "saludo": "bowing bow ceremony rei otagai-ni",
        "saludos": "bowing bow ceremony rei",
        "saludar": "bowing bow rei",
        "reverencia": "bowing bow rei",
        "equipo": "team teams encounter",
        "equipos": "team teams encounter",
        "mixto": "mixed team teams",
        "mixtos": "mixed team teams",
        "mixta": "mixed team teams",
        "mixtas": "mixed team teams",
        "tolerancia": "tolerance",
        "presentarse": "appear appearance failure to appear",
        "presenta": "appear appearance failure to appear",
        "presentan": "appear appearance failure to appear",
        "comparecer": "appear appearance failure to appear",
        "comparecencia": "appear appearance failure to appear",
        "incomparecencia": "failure to appear",
        "simultanea": "simultaneous both fall tatami",
        "simultaneo": "simultaneous both fall tatami",
        "simultaneas": "simultaneous both fall tatami",
        "dopaje": "doping control anti-doping",
        "disciplinario": "disciplinary committee code sanctions",
        "disciplinaria": "disciplinary committee code sanctions",
        "dimensiones": "dimensions",
        "dimension": "dimensions",
        "inmovilizacion": "osaekomi",
        "inmovilizaciones": "osaekomi",
        "actos": "acts",
        "prohibidos": "prohibited",
        "prohibido": "prohibited",
        "suelo": "groundwork ground floor mat",
        "criterio": "criteria",
        "criterios": "criteria",
        "comportamiento": "behaviour conduct",
        "conducta": "behaviour conduct",
        "tatami": "tatami competition area",
        "sistema": "system",
        "sistemas": "systems",
        "competicion": "competition",
        "competiciones": "competitions",
        "empujar": "pushing push forced out outside contest area",
        "empuja": "pushing push forced out outside contest area",
        "empujando": "pushing push forced out outside contest area",
        "deliberadamente": "intentionally intentional",
        "deliberada": "intentionally intentional",
        "convencional": "conventional grip",
        "inmediato": "immediate attack positive attack",
        "inmediata": "immediate attack positive attack",
        "regla": "rules rule",
        "reglas": "rules",
        "cuadro": "draw bracket",
        "cuadros": "draw brackets",
        "llave": "draw bracket",
        "llaves": "draw brackets",
        "diagrama": "diagram draw",
        "diagramas": "diagrams draw",
        "plantilla": "form sheet template",
        "plantillas": "forms sheets templates",
        "torneo": "tournament contest",
        "enfrentamiento": "contest match",
        "enfrentamientos": "contests matches",
        "distribuyen": "divided draw",
        "distribucion": "distribution draw",
        "vendaje": "taping bandage tape",
        "vendajes": "taping bandage bandages tape",
        "dedo": "finger toe",
        "dedos": "finger fingers toe toes",
        "sokuteiki": "sokuteiki judogi control size",
        "medida": "size measurement",
        "medidas": "size measurements",
        "manga": "sleeve",
        "mangas": "sleeves",
        "faldon": "skirt bottom shime-waza",
        "competidor": "athlete competitor",
        "competidores": "athletes competitors",
        "regresa": "return returning",
        "regresar": "return returning",
        "posicion": "position",
        "inicio": "starting start",
        "corresponde": "assigned correct",
        "quedandose": "failing stand ground",
        "perdiendo": "wasting time-wasting",
        "perder": "wasting time-wasting",
        "sobrepasa": "goes beyond limit outside",
        "sobrepasar": "goes beyond limit outside",
        "alcanza": "beyond limit",
        "alcanzar": "beyond limit",
        "limite": "limit",
        "limites": "limits",
        "exterior": "outside beyond",
        "seguridad": "safety",
        "continuidad": "continue continuing uninterrupted",
        "continuar": "continue",
        "agarre": "grip holding",
        "aterriza": "landing land lands",
        "aterrizar": "landing land lands",
        "aterrizaje": "landing land",
        "cuerpo": "body",
        "color": "colour color",
        "colores": "colour colours color colors",
        "colours": "colour",
        "cinturon": "belt shime-waza encircle",
        "cinturones": "belt belts shime-waza encircle",
        "permitido": "allowed permitted",
        "permitidos": "allowed permitted",
        "permitida": "allowed permitted",
        "permitidas": "allowed permitted",
        "marca": "brand logo marking",
        "marcas": "brands logos markings",
        "parche": "patch backnumber",
        "parches": "patches backnumbers",
        "dorsal": "backnumber",
        "dorsales": "backnumbers",
        "chaqueta": "jacket",
        "pantalon": "trousers",
        "pantalones": "trousers",
        "cuello": "collar",
        "solapa": "lapel",
        "solapas": "lapels",
        "etiqueta": "label",
        "etiquetas": "labels",
        "publicidad": "advertising",
        "emblema": "emblem",
        "emblemas": "emblems",
        "reversible": "reversible",
        "reversibles": "reversible",
        "rodilla": "joint knee ashi-garami kansetsu-waza elbow",
        "rodillas": "joint knee ashi-garami kansetsu-waza elbow",
        "tobillo": "joint ankle ashi-garami kansetsu-waza elbow",
        "tobillos": "joint ankle ashi-garami kansetsu-waza elbow",
        "palanca": "kansetsu-waza joint lock armlock",
        "palancas": "kansetsu-waza joint lock armlocks",
        "desatado": "unfastened untied shime-waza",
        "desatada": "unfastened untied shime-waza",
        "pretina": "belt shime-waza encircle",
        "tirarse": "diving head",
        "zambullirse": "diving dive head",
        "meter": "insert foot leg belt lapel",
        "pie": "foot leg belt lapel",
        "intervencion": "medical treatment assistance occasions doctor",
        "intervenciones": "medical treatment assistance occasions doctor",
        "medica": "medical treatment assistance doctor",
        "medicas": "medical treatment assistance doctor occasions",
        "medico": "doctor medical treatment",
        "medicos": "doctor doctors medical",
        "asistencia": "assistance medical treatment doctor",
        "atencion": "assistance medical treatment doctor",
        "doctor": "doctor medical",
        "cuantas": "occasions times maximum",
        "cuantos": "occasions times maximum",
        "permiten": "allowed permitted receive",
        "permite": "allowed permitted receive",
        "desmaya": "loses consciousness unconscious shime-waza strangulation",
        "desmayo": "loss consciousness unconscious shime-waza strangulation",
        "desmayarse": "lose consciousness unconscious shime-waza strangulation",
        "estrangulacion": "shime-waza strangulation strangle choke",
        "estrangulación": "shime-waza strangulation strangle choke",
        "pesaje": "weigh-in weight official random",
        "aleatorio": "random weigh-in tolerance",
        "tolerancia": "tolerance",
        "fusen": "fusen-gachi default failure to appear",
        "fusengachi": "fusen-gachi default failure to appear",
        "comparecencia": "appear contest tatami",
        "presentarse": "appear contest tatami",
        "presentacion": "appear contest tatami",
        "smart": "smart judogi approved optical label chip",
        "chip": "optical label approved judogi control",
        "nfc": "optical label approved judogi control",
        "optica": "optical label judogi control",
        "optico": "optical label judogi control"
    }

    def _tokenize(self, text):
        clean = text.lower().replace("á", "a").replace("é", "e").replace("í", "i").replace("ó", "o").replace("ú", "u").replace("ñ", "n")
        raw_tokens = re.findall(r"\b[a-zA-Z0-9_\-]{2,}\b", clean)
        tokens = []
        for t in raw_tokens:
            if t not in STOPWORDS:
                tokens.append(t)
                if "-" in t:
                    parts = [p for p in t.split("-") if len(p) >= 2 and p not in STOPWORDS]
                    tokens.extend(parts)
                if t in self.SPANISH_TO_ENGLISH_SYNONYMS:
                    syn = self.SPANISH_TO_ENGLISH_SYNONYMS[t]
                    tokens.extend(syn.split())

        # Normative Ontology Expansion (Phase 1 RRE 3.0)
        expanded_tokens, detected_domains = NormativeOntology.expand_token_stream(tokens)
        
        # Dampen procedural generic words if specific normative domains are detected
        if detected_domains and not any(d in detected_domains for d in [NormativeDomain.DRAW_AND_CONTEST_SYSTEM]):
            # If the query is about specific actions, penalties, ethics, head, etc.,
            # dampen procedural generic tokens (competitor, athlete, team) so table templates don't dominate BM25
            filtered_tokens = []
            for t in expanded_tokens:
                if t in NormativeOntology.PROCEDURAL_DAMPEN_WORDS and t in {"competitor", "competitors", "athlete", "athletes", "team", "teams"}:
                    continue
                filtered_tokens.append(t)
            if filtered_tokens:
                expanded_tokens = filtered_tokens

        return expanded_tokens

    def _sparse_search(self, query, top_k=20):
        tokens = self._tokenize(query)
        if not tokens or not self.sparse_index:
            return []

        counts = Counter(tokens)
        idf = self.sparse_index.get("idf", {})
        q_vec = {}
        q_norm_sq = 0.0
        for t, c in counts.items():
            w = (c / len(tokens)) * idf.get(t, 1.0)
            q_vec[t] = w
            q_norm_sq += w * w
        q_norm = math.sqrt(q_norm_sq) or 1.0
        q_vec = {t: w / q_norm for t, w in q_vec.items()}

        scores = []
        for pid, d_vec in self.sparse_index.get("vectors", {}).items():
            dot = sum(q_vec[t] * d_vec.get(t, 0.0) for t in q_vec)
            if dot > 0.02:
                scores.append((pid, dot))

        scores.sort(key=lambda x: x[1], reverse=True)
        return scores[:top_k]

    def _dense_search(self, query, top_k=20):
        if self.dense_model is None or self.dense_embeddings is None:
            return []

        q_emb = self.dense_model.encode(query, normalize_embeddings=True)
        sims = np.dot(self.dense_embeddings, q_emb)

        # Cross-lingual dense projection for non-English queries containing mapped technical terms
        clean = query.lower().replace("á", "a").replace("é", "e").replace("í", "i").replace("ó", "o").replace("ú", "u").replace("ñ", "n")
        raw_tokens = re.findall(r"\b[a-zA-Z0-9_\-]{2,}\b", clean)
        eng_parts = []
        for t in raw_tokens:
            if t not in STOPWORDS:
                if t in self.SPANISH_TO_ENGLISH_SYNONYMS:
                    eng_parts.append(self.SPANISH_TO_ENGLISH_SYNONYMS[t])
                else:
                    eng_parts.append(t)
        eng_query = " ".join(eng_parts)

        if eng_query and eng_query != query:
            q_emb_proj = self.dense_model.encode(eng_query, normalize_embeddings=True)
            sims_proj = np.dot(self.dense_embeddings, q_emb_proj)
            sims = np.maximum(sims, sims_proj)

        top_indices = np.argsort(sims)[::-1][:top_k]
        passage_ids = self.dense_meta.get("passage_ids", [p["passage_id"] for p in self.passages])
        results = []
        for idx in top_indices:
            score = float(sims[idx])
            if score > 0.15:
                results.append((passage_ids[idx], score))
        return results

    def _query_requests_document_history(self, query: str) -> bool:
        """Allow the version-history appendix only when the user explicitly asks about revisions."""
        normalized = (
            query.lower()
            .replace("á", "a").replace("é", "e").replace("í", "i")
            .replace("ó", "o").replace("ú", "u").replace("ñ", "n")
        )
        history_markers = (
            "version history", "document version history", "history of changes",
            "change log", "previous version", "version changes", "sor amendments",
            "regulation updates", "historial de versiones", "historial de cambios",
            "version anterior", "versiones anteriores", "cambios de version",
            "que cambio", "que cambios hubo", "actualizaciones del reglamento",
            "modificaciones del reglamento"
        )
        return any(marker in normalized for marker in history_markers)

    def _is_version_history_passage(self, passage_id: str) -> bool:
        """Identify passages indexed under document-control/version-history headings."""
        passage = self.passages_by_id.get(passage_id, {})
        headings = " ".join(str(item) for item in passage.get("heading_path", [])).lower()
        article_id = str(passage.get("article_id", "")).strip().lower()
        return (
            article_id == "h1.1"
            or "document version history" in headings
            or headings.strip() == "document control"
        )

    def retrieve(self, query: str, top_k: int = 5, min_confidence: float = 0.015, expand_graph: bool = True,
                 domain_query: Optional[str] = None):
        """
        Executes Reasoning Retrieval with Reciprocal Rank Fusion (RRF) and Graph Expansion.
        """
        # 1. Domain Validation & Tokenization
        tokens = self._tokenize(query)
        if not tokens:
            return {
                "status": "ABSTAIN",
                "reason": "EMPTY_OR_NON_SUBSTANTIVE_QUERY",
                "message": "La consulta no contiene términos normativos o técnicos válidos.",
                "evidence": [],
                "related_passages": [],
                "operating_mode": self.operating_mode,
                "degradation_reason": self.degradation_reason,
                "source_sha256_verified": self.source_sha256_verified
            }

        # 2. Dual-channel retrieval
        # No mezclar el apéndice de historial con reglas vigentes salvo que el usuario pregunte por revisiones.
        requests_history = self._query_requests_document_history(query)
        sparse_hits = [
            hit for hit in self._sparse_search(query, top_k=25)
            if hit[1] >= 0.05
            and (requests_history or not self._is_version_history_passage(hit[0]))
        ]
        dense_hits = [
            hit for hit in self._dense_search(query, top_k=25)
            if requests_history or not self._is_version_history_passage(hit[0])
        ]

        # 3. Domain Grounding & Dual-channel verification
        # Verificación de anclaje de dominio: al menos un término sustantivo directo de la consulta
        # (excluyendo expansiones ontológicas globales de shido/falta) debe pertenecer al vocabulario del corpus,
        # o bien formularse una referencia verificable a una página física del SOR 2026-08 (1 a 298).
        # Se excluyen términos genéricos transversales (rules, rule, system, systems, falta, personal, libre, sancion)
        # para evitar que consultas OOD de otros deportes (e.g. básquetbol) superen el umbral.
        GENERIC_WORDS = {"rules", "rule", "system", "systems", "faltas", "personal", "personales", "libre", "libres"}
        vocab = self.sparse_index.get("idf", {})
        
        # Evaluar anclaje directo de la consulta original
        clean_q_direct = query.lower().replace("á", "a").replace("é", "e").replace("í", "i").replace("ó", "o").replace("ú", "u").replace("ñ", "n")
        raw_direct_tokens = re.findall(r"\b[a-zA-Z0-9_\-]{2,}\b", clean_q_direct)
        direct_tokens = [t for t in raw_direct_tokens if t not in STOPWORDS]
        substantive_in_vocab = {t for t in direct_tokens if t in vocab and not t.isdigit() and t not in GENERIC_WORDS}
        for t in direct_tokens:
            if t in self.SPANISH_TO_ENGLISH_SYNONYMS and t not in GENERIC_WORDS:
                for s in self.SPANISH_TO_ENGLISH_SYNONYMS[t].split():
                    if s in vocab and s not in GENERIC_WORDS:
                        substantive_in_vocab.add(s)

        JUDO_TECHNICAL_IMMUNITY = {
            "descalificacion", "sancion", "inmovilizacion", "shido",
            "hansoku-make", "osaekomi", "duracion", "combate",
            "pesaje", "tatami", "puente", "cabeza", "repesca",
            "insulto", "insulta", "agresion", "agresión", "agrede",
            "antideportiva", "reverse", "seoi-nage", "seoinage",
            "veterano", "veteranos", "master", "masters", "veteran", "veterans",
            "antidopaje", "dopaje", "doping", "anti-doping",
            "disciplinario", "disciplinaria", "disciplinary",
            "entrenador", "entrenadores", "coach", "coaches", "vestimenta",
            "saludo", "saludos", "saludar", "reverencia", "equipo", "equipos", "mixto", "mixtos",
            "tolerancia", "presentarse", "presenta", "comparecer", "comparecencia", "incomparecencia",
            "simultanea", "simultaneo", "simultaneas", "fusen-gachi", "fusengachi"
        }
        for t in raw_direct_tokens:
            if t in JUDO_TECHNICAL_IMMUNITY:
                substantive_in_vocab.add("judo_technical_anchor")

        page_refs = re.findall(r'\b(?:p[aá]gina|p[aá]g\.?|page)\s*(\d+)\b', query, re.IGNORECASE)
        has_valid_page_ref = any(1 <= int(p) <= 298 for p in page_refs)

        # Evaluacion BK-01: Negative Domain Anchor Scoring
        neg_anchor_result = None
        if self.enable_negative_domain_anchors or self.shadow_mode_negative_anchors or self.enable_ood_detector:
            # Phase 6 (C1): negative-domain anchors describe the user's own words. When the retrieval
            # query is a translation/projection, score the original query so that vocabulary injected
            # by the translation (e.g. 'penalty') cannot by itself mark a judo question as another sport.
            neg_anchor_result = NegativeDomainAnchorScorer.score_negative_domain(domain_query or query)
            # En modo activo (no solo shadow), si se confirma OOD negativo inequívoco sin inmunidad de judo:
            if self.enable_negative_domain_anchors and not self.shadow_mode_negative_anchors:
                if neg_anchor_result.is_ood and not has_valid_page_ref:
                    return {
                        "status": "ABSTAIN",
                        "reason": "OUT_OF_DOMAIN",
                        "message": f"Consulta identificada fuera del dominio Judo por anclas negativas de {', '.join(neg_anchor_result.detected_domains)}.",
                        "evidence": [],
                        "related_passages": [],
                        "operating_mode": self.operating_mode,
                        "degradation_reason": self.degradation_reason,
                        "source_sha256_verified": self.source_sha256_verified,
                        "negative_domain_metrics": neg_anchor_result.model_dump()
                    }

        # OOD Detector (Phase 3 continuous metric abstention if enabled)
        if self.enable_ood_detector and self.ood_detector:
            top_dense = dense_hits[0][1] if dense_hits else 0.0
            top_sparse = sparse_hits[0][1] if sparse_hits else 0.0
            ood_eval = self.ood_detector.evaluate_grounding(query, sparse_top=top_sparse, dense_top=top_dense)
            is_negative_ood = bool(neg_anchor_result and neg_anchor_result.is_ood)
            if not ood_eval.get("is_in_domain", True) and not has_valid_page_ref and (is_negative_ood or not substantive_in_vocab):
                return {
                    "status": "ABSTAIN",
                    "reason": "OUT_OF_DOMAIN",
                    "message": "Sin evidencia normativa certificada en el SOR 2026-08 para los términos consultados.",
                    "evidence": [],
                    "related_passages": [],
                    "operating_mode": self.operating_mode,
                    "degradation_reason": self.degradation_reason,
                    "source_sha256_verified": self.source_sha256_verified,
                    "ood_metrics": ood_eval,
                    "shadow_negative_metrics": neg_anchor_result.model_dump() if neg_anchor_result else None
                }

        if not substantive_in_vocab and not has_valid_page_ref and (not dense_hits or dense_hits[0][1] < 0.45):
            return {
                "status": "ABSTAIN",
                "reason": "OUT_OF_DOMAIN",
                "message": "Sin evidencia normativa certificada en el SOR 2026-08 para los términos consultados.",
                "evidence": [],
                "related_passages": [],
                "operating_mode": self.operating_mode,
                "degradation_reason": self.degradation_reason,
                "source_sha256_verified": self.source_sha256_verified
            }

        # Si no hay anclaje léxico suficiente ni referencia a página válida, la similitud densa debe ser claramente relevante (>0.35)
        if not sparse_hits and not has_valid_page_ref and (not dense_hits or dense_hits[0][1] < 0.35):
            return {
                "status": "ABSTAIN",
                "reason": "OUT_OF_DOMAIN",
                "message": "Sin evidencia normativa certificada en el SOR 2026-08 para los términos consultados.",
                "evidence": [],
                "related_passages": [],
                "operating_mode": self.operating_mode,
                "degradation_reason": self.degradation_reason,
                "source_sha256_verified": self.source_sha256_verified
            }

        k_rrf = 60
        rrf_scores = {}
        for rank, (pid, score) in enumerate(sparse_hits, 1):
            rrf_scores[pid] = rrf_scores.get(pid, 0.0) + (1.2 / (k_rrf + rank))

        for rank, (pid, score) in enumerate(dense_hits, 1):
            rrf_scores[pid] = rrf_scores.get(pid, 0.0) + (1.0 / (k_rrf + rank))

        # Recompensa por concordancia multi-canal y alta precisión léxica
        sparse_map = dict(sparse_hits)
        dense_map = dict(dense_hits)
        for pid in rrf_scores:
            if pid in sparse_map and pid in dense_map:
                rrf_scores[pid] = (rrf_scores[pid] + 0.035) * 1.35
            elif pid in sparse_map and sparse_map[pid] >= 0.20:
                rrf_scores[pid] += 0.035

        # Prioritise substantive operational articles over Appendix H1.1 (Document Version History)
        # when query does not specifically request history/amendments
        is_history_query = any(w in query.lower() for w in ["history", "historial", "version", "cambio", "modificacion"])
        if not is_history_query:
            for pid in rrf_scores:
                p = self.passages_by_id.get(pid)
                if p and 259 <= p.get("pdf_page_index", 0) <= 298:
                    rrf_scores[pid] *= 0.40

        # Recompensa específica de frontera normativa (osaekomi / ne-waza sobrepasando área de seguridad o fuera del área de combate)
        clean_q_lower = query.lower()
        has_boundary_term = any(w in clean_q_lower for w in ["seguridad", "safety", "limite", "limit", "sobrepasa", "beyond", "exterior"])
        has_outside_contest = any(w in clean_q_lower for w in ["fuera", "outside"]) and any(w in clean_q_lower for w in ["combate", "contest", "area", "tatami"])
        has_osaekomi_term = any(w in clean_q_lower for w in ["osaekomi", "inmovilizacion", "inmovilización"])
        has_newaza_term = any(w in clean_q_lower for w in ["ne-waza", "newaza", "suelo", "kansetsu", "shime", "agarre"])

        if has_boundary_term and has_osaekomi_term:
            # Art. 17 P174 establece taxativamente Ippon Sore-Made cuando osaekomi sobrepasa el área de seguridad
            if "SOR-2026-08-P174-S190" in rrf_scores:
                rrf_scores["SOR-2026-08-P174-S190"] += 0.12
        elif has_boundary_term and has_newaza_term:
            # Art. 5(d) P152 establece el protocolo para kansetsu/shime fuera de seguridad
            if "SOR-2026-08-P152-S179" in rrf_scores:
                rrf_scores["SOR-2026-08-P152-S179"] += 0.08
            elif "SOR-2026-08-P151-S178" in rrf_scores:
                rrf_scores["SOR-2026-08-P151-S178"] += 0.08
        elif has_outside_contest and has_newaza_term:
            # Art. 5(b)/(c) P151 regula la validez de ne-waza continuado fuera del área de combate
            if "SOR-2026-08-P151-S178" in rrf_scores:
                rrf_scores["SOR-2026-08-P151-S178"] += 0.10

        # Controlled topical alignment for equipment regulations (Appendix C)
        clean_q_lower = query.lower()
        is_boundary_newaza = any(w in clean_q_lower for w in ["fuera", "outside", "seguridad", "safety", "limite", "límite", "continuidad"]) and any(w in clean_q_lower for w in ["ne-waza", "newaza", "suelo", "osaekomi"])
        is_kumikata_grip_query = not is_boundary_newaza and any(w in clean_q_lower for w in [
            "agarre", "agarres", "agarrar", "kumikata", "kumi-kata", "grip", "grips",
            "cross grip", "pocket grip", "pistol grip", "same-side", "belt grip",
            "inside sleeve", "bocamanga", "interlocking", "dedos entrelazados", "entrelazar",
            "leg grabbing", "romper", "ruptura", "bloqueo", "posicion encorvada", "posición encorvada",
            "brazos rigidos", "brazos rígidos", "bending position", "blocking attitude"
        ])
        is_belt_query = any(w in clean_q_lower for w in ["cinturon", "cinturón", "belt"]) and not is_kumikata_grip_query
        is_judogi_color_query = any(w in clean_q_lower for w in ["color", "colores", "colour", "colours"]) and any(w in clean_q_lower for w in ["judogi", "traje", "uniforme"]) and not is_belt_query
        is_sleeve_query = any(w in clean_q_lower for w in ["manga", "mangas", "sleeve", "sleeves", "sokuteiki"]) and not is_kumikata_grip_query
        is_mark_query = any(w in clean_q_lower for w in ["marca", "marcas", "parche", "parches", "dorsal", "dorsales", "patch", "logo", "advertising", "publicidad", "emblema"])

        if is_belt_query:
            for pid in rrf_scores:
                p = self.passages_by_id.get(pid)
                if p:
                    text_p = p.get("text_original", "").lower()
                    head_p = " ".join(p.get("heading_path", [])).lower()
                    if any(term in text_p for term in ["belt of a colour", "red and white belt", "belt label can be red"]):
                        rrf_scores[pid] += 0.08
                    elif "belt" in head_p or "belt" in text_p:
                        rrf_scores[pid] += 0.02
                    if "judogi colour" in head_p:
                        rrf_scores[pid] -= 0.06
        elif is_judogi_color_query:
            for pid in rrf_scores:
                p = self.passages_by_id.get(pid)
                if p:
                    head_p = " ".join(p.get("heading_path", [])).lower()
                    text_p = p.get("text_original", "").lower()
                    if "judogi colour" in head_p or "c1.9" in head_p:
                        rrf_scores[pid] += 0.08
                    if "uniform colour" in text_p:
                        rrf_scores[pid] += 0.03
        elif is_sleeve_query:
            for pid in rrf_scores:
                p = self.passages_by_id.get(pid)
                if p:
                    head_p = " ".join(p.get("heading_path", [])).lower()
                    text_p = p.get("text_original", "").lower()
                    if "size" in head_p or "c1.10" in head_p:
                        rrf_scores[pid] += 0.06
                    if "sleeve" in text_p or "sokuteiki" in text_p:
                        rrf_scores[pid] += 0.03
        elif is_mark_query:
            for pid in rrf_scores:
                p = self.passages_by_id.get(pid)
                if p:
                    head_p = " ".join(p.get("heading_path", [])).lower()
                    if any(h in head_p for h in ["logo", "marking", "backnumber", "advertising", "emblem", "label"]):
                        rrf_scores[pid] += 0.06

        # Controlled topical alignment for head actions (Appendix D Refereeing Rules)
        has_bridge_term = any(w in clean_q_lower for w in ["puente", "bridge"])
        has_hansoku_term = any(w in clean_q_lower for w in ["hansoku", "hansoku-make", "hansokumake", "descalificacion", "descalificación", "directo"])
        has_head_term = any(w in clean_q_lower for w in ["cabeza", "head", "craneo", "cráneo", "cervical", "cuello"]) or has_bridge_term
        is_cadet_specific = any(w in clean_q_lower for w in ["cadet", "cadete", "cadetes", "u18", "sub18", "sub-18"])
        is_senior_junior_specific = any(w in clean_q_lower for w in ["senior", "seniors", "junior", "juniors", "adulto", "adultos"])
        is_dive_specific = any(w in clean_q_lower for w in ["dive", "diving", "clavado", "clavar", "zambullida", "buceo", "somersault"])
        is_bridge_specific = has_bridge_term
        is_defense_specific = any(w in clean_q_lower for w in ["defensa", "defender", "defiende", "defend", "defence", "defense", "defensive", "escapar", "escape", "evitar"])
        is_throw_by_tori = any(w in clean_q_lower for w in ["proyectar", "proyeccion", "proyección", "lanzar", "lanzamiento", "throw", "tori"])
        is_concussion_specific = any(w in clean_q_lower for w in ["conmocion", "conmoción", "concussion", "trauma", "inhabilitacion", "inhabilitación", "suspension", "suspensión", "dias", "días", "days"])

        if has_head_term:
            # 1. Regla General de Puente de Uke (Art. 14.2, Págs. 166-167): evaluado como Ippon por seguridad cervical
            if is_bridge_specific or is_defense_specific:
                for bridge_pid in ("SOR-2026-08-P166-S187", "SOR-2026-08-P167-S187"):
                    if bridge_pid in self.passages_by_id and bridge_pid not in rrf_scores:
                        rrf_scores[bridge_pid] = 0.025
                for pid in list(rrf_scores):
                    p = self.passages_by_id.get(pid)
                    if p and p.get("pdf_page_index") in (166, 167):
                        text_p = p.get("text_original", "").lower()
                        if "bridge" in text_p or "voluntarily makes a" in text_p or "cervical" in text_p:
                            rrf_scores[pid] += 0.12 if not is_cadet_specific else 0.07

            # 2. Regla de Head Diving / Hansoku-make por técnica de cabeza (Art. 18.2.1 / 18.2.2, Pág. 190)
            if is_dive_specific or is_throw_by_tori or has_hansoku_term or (not is_defense_specific and not is_concussion_specific):
                for h_pid in ("SOR-2026-08-P190-S197", "SOR-2026-08-P190-S198"):
                    if h_pid in self.passages_by_id and h_pid not in rrf_scores:
                        rrf_scores[h_pid] = 0.025
                for pid in list(rrf_scores):
                    p = self.passages_by_id.get(pid)
                    if p and p.get("pdf_page_index") == 190:
                        text_p = p.get("text_original", "").lower()
                        if "head diving" in text_p or "article 18 .2 .1" in text_p or "hansoku-make" in text_p:
                            bonus = 0.14 if has_hansoku_term else (0.11 if not is_cadet_specific else 0.06)
                            if pid == 'SOR-2026-08-P190-S197' or str(p.get('article_id')) == 'Article 18.2.1':
                                bonus += 0.03
                            rrf_scores[pid] += bonus

            # 4. Atenuación de pasajes irrelevantes cuando se indaga sobre arbitraje de cabeza en combate
            if not is_concussion_specific:
                for pid in list(rrf_scores):
                    p = self.passages_by_id.get(pid)
                    if p:
                        if p.get("pdf_page_index") == 202 and not is_concussion_specific:
                            rrf_scores[pid] *= 0.65
                        elif p.get("pdf_page_index") in (138, 149, 150) and not any(w in clean_q_lower for w in ["gesto", "gesture", "senal", "señal"]):
                            rrf_scores[pid] *= 0.70

        # Reglas Específicas de Cadetes (Art. 18.1.4, Págs. 188-189): evaluadas independientemente de mención de cabeza
        if is_cadet_specific or ((is_defense_specific or is_throw_by_tori or is_senior_junior_specific) and has_head_term):
            is_reverse_seoi = any(w in clean_q_lower for w in ["reverse", "seoi-nage", "seoi", "inversa"])
            cadet_target_pid = "SOR-2026-08-P189-S196" if is_reverse_seoi else "SOR-2026-08-P188-S196"
            if cadet_target_pid in self.passages_by_id and cadet_target_pid not in rrf_scores:
                rrf_scores[cadet_target_pid] = 0.035
            for pid in list(rrf_scores):
                p = self.passages_by_id.get(pid)
                if p:
                    if p.get("pdf_page_index") == 188 and "18.1.4" in str(p.get("article_id", "")):
                        rrf_scores[pid] += 0.18 if (is_cadet_specific and not is_reverse_seoi) else 0.08
                    elif p.get("pdf_page_index") == 189 and "18.1.4" in str(p.get("article_id", "")):
                        rrf_scores[pid] += 0.22 if is_reverse_seoi else 0.04

            # Dampen general contest area (Art. 5) when querying cadet technique restrictions (never dampen contest duration Art. 6 or osaekomi Art. 7)
            is_duration_or_time_query = any(w in clean_q_lower for w in ["dura", "duration", "tiempo", "time", "minuto", "minute", "osaekomi", "segundo", "second"])
            if not is_duration_or_time_query and not any(w in clean_q_lower for w in ["area", "área", "zona", "fuera", "outside", "border"]):
                for pid in list(rrf_scores):
                    p = self.passages_by_id.get(pid)
                    if p:
                        art = str(p.get("article_id", "")).lower()
                        # Only dampen Article 5 (Contest area), never Article 6 (Duration) or Article 7 (Osaekomi)
                        if "article 5" in art:
                            rrf_scores[pid] *= 0.20

        # Reglas de Conducta, Ética, Insultos, Agresiones y Actos contra el Espíritu del Judo (Art. 18.2.2, Págs. 190, 193)
        has_conduct_term = any(w in clean_q_lower for w in [
            "insult", "insulto", "insultos", "insulta", "agresion", "agresión", "agrede",
            "derogatory", "spirit of judo", "espiritu del judo", "espíritu del judo",
            "antideportiva", "antideportivo", "anti-judo", "violencia", "conducta"
        ])
        if has_conduct_term:
            for conduct_pid in ("SOR-2026-08-P193-S198", "SOR-2026-08-P190-S198"):
                if conduct_pid in self.passages_by_id:
                    if conduct_pid not in rrf_scores:
                        rrf_scores[conduct_pid] = 0.040
                    rrf_scores[conduct_pid] += 0.22
            # Atenuar gestos arbitrales de judogi/cabello, inmovilizaciones y shidos ordinarios
            for pid in list(rrf_scores):
                p = self.passages_by_id.get(pid)
                if not p:
                    continue
                art = str(p.get("article_id", "")).lower()
                page = p.get("pdf_page_index", 0)
                if page in (137, 138, 147, 148, 149, 150, 151, 160, 161, 173, 175) or "article 4" in art or "gestures" in str(p.get("heading_path", "")).lower():
                    rrf_scores[pid] *= 0.10

        # Controlled topical alignment for kumikata and illegal moves (Article 18.1.2, Págs. 178-185)
        if is_kumikata_grip_query:
            is_pocket_pistol = any(w in clean_q_lower for w in ["pocket", "pistol"])
            is_cross_grip = any(w in clean_q_lower for w in ["cross", "cruzado"])
            is_bending_or_blocking = any(w in clean_q_lower for w in ["encorvada", "bloqueo", "rigido", "rígido", "rigidos", "rígidos", "bending", "blocking"])
            is_under_belt = any(w in clean_q_lower for w in ["muslo", "cinturon", "cinturón"]) and not any(w in clean_q_lower for w in ["manga", "sleeve", "bocamanga"])
            is_leg_grabbing = any(w in clean_q_lower for w in ["pierna", "pantalon", "pantalón"]) and any(w in clean_q_lower for w in ["agarrar", "tocar", "sancion", "sanción", "falta", "grabbing"])
            is_breaking_grips = any(w in clean_q_lower for w in ["romper", "ruptura", "soltando", "liberando", "conservando", "dos manos"])
            is_inside_sleeve_or_trouser = any(w in clean_q_lower for w in ["bocamanga", "sleeve", "trouser", "pantalon", "pantalón", "dentro"]) and any(w in clean_q_lower for w in ["dentro", "inside", "bocamanga"])
            is_interlocking = any(w in clean_q_lower for w in ["interlocking", "entrelazados", "entrelazar"]) or ("dedos" in clean_q_lower and any(w in clean_q_lower for w in ["continuamente", "sanciona", "sanción", "interlocking"]))

            for pid in list(rrf_scores):
                p = self.passages_by_id.get(pid)
                if not p:
                    continue
                art = str(p.get("article_id", "")).lower()
                page = p.get("pdf_page_index", 0)

                # Dampen referee gestures when asking about substantive illegal moves
                if ("article 4" in art or "gestures" in str(p.get("heading_path", "")).lower() or 137 <= page <= 151) and not any(w in clean_q_lower for w in ["gesto", "gesture", "senal", "señal"]):
                    rrf_scores[pid] *= 0.20

                # Dampen equipment sizing / sokuteiki when asking about combat grips
                if ("c1.10" in art or "size" in str(p.get("heading_path", "")).lower() or 115 <= page <= 127) and not any(w in clean_q_lower for w in ["sokuteiki", "tamano", "tamaño", "medida", "medidas", "calibrador"]):
                    rrf_scores[pid] *= 0.20

                # Dampen exam / education appendix
                if 250 <= page <= 275:
                    rrf_scores[pid] *= 0.20

                # Boost Article 18.1.2
                if "18.1.2" in art or (178 <= page <= 185):
                    rrf_scores[pid] *= 1.40

                    # Fine-grained page affinity for substantive rules
                    if (is_pocket_pistol or is_cross_grip or is_bending_or_blocking) and page == 178:
                        rrf_scores[pid] += 0.25
                    elif is_under_belt and page == 179:
                        rrf_scores[pid] += 0.25
                    elif is_leg_grabbing and page in (179, 180, 183):
                        rrf_scores[pid] += 0.18
                    elif (is_breaking_grips or is_inside_sleeve_or_trouser or is_interlocking) and page == 180:
                        rrf_scores[pid] += 0.25

        # Controlled exact normative code and title alignment signal
        if self.enable_code_matching:
            code_matches = re.findall(r'\b(?:article\s*(\d+)|([a-z]{1,2}\d+(?:\.\d+)*|\d+(?:\.\d+)+))\b', query, re.IGNORECASE)
            query_codes = [m[0] or m[1] for m in code_matches]
            if query_codes:
                query_substantive = {t for t in tokens if not any(t.lower() in c.lower() or c.lower() in t.lower() for c in query_codes)}
                for p in self.passages:
                    pid = p["passage_id"]
                    p_art = str(p.get("article_id", "")).lower()
                    p_heading = str(p.get("heading_path", [""])[0]).lower()
                    for c in query_codes:
                        c_low = c.lower()
                        if p_art == c_low or p_heading.startswith(c_low + " ") or p_heading == c_low:
                            if query_substantive:
                                p_text_words = set(re.findall(r"\b[a-zA-Z0-9_\-]{2,}\b", p.get("text_original", "").lower()))
                                if query_substantive & p_text_words:
                                    rrf_scores[pid] = rrf_scores.get(pid, 0.0) + 0.05
                            else:
                                # Standalone code query: prefer passages with real content
                                if len(p.get("text_original", "").strip()) >= 100:
                                    rrf_scores[pid] = rrf_scores.get(pid, 0.0) + 0.05

        # Explicit physical page reference routing & normative substantive linking
        page_matches = re.findall(r'\b(?:p[aá]gina|p[aá]g\.?|page)\s*(\d+)\b', query, re.IGNORECASE)
        if page_matches:
            target_page = int(page_matches[0])
            # Direct map from F1.3 diagram templates (pages 213-230) to substantive Section 2 articles
            f1_to_sec2 = {
                "f1.3.6": ["SOR-2026-08-P038-S042"],  # 2.5.1 Direct Knockout
                "f1.3.7": ["SOR-2026-08-P038-S043"],  # 2.5.2 Quarter-final Repechage
                "f1.3.8": ["SOR-2026-08-P038-S043"],
                "f1.3.9": ["SOR-2026-08-P038-S043"],
                "f1.3.10": ["SOR-2026-08-P038-S043"],
                "f1.3.11": ["SOR-2026-08-P038-S043"],
                "f1.3.12": ["SOR-2026-08-P038-S044"], # 2.5.3 Double Repechage
                "f1.3.13": ["SOR-2026-08-P038-S044"],
                "f1.3.14": ["SOR-2026-08-P038-S044"],
                "f1.3.15": ["SOR-2026-08-P038-S044"], # Double Repechage up to 8
                "f1.3.16": ["SOR-2026-08-P038-S045"], # 2.5.4 Full Repechage
                "f1.3.17": ["SOR-2026-08-P038-S045"],
                "f1.3.18": ["SOR-2026-08-P039-S046", "SOR-2026-08-P039-S047"], # 2.5.5 Round Robin
                "f1.3.19": ["SOR-2026-08-P039-S046", "SOR-2026-08-P039-S047"],
                "f1.3.20": ["SOR-2026-08-P039-S046", "SOR-2026-08-P039-S047"],
                "f1.3.21": ["SOR-2026-08-P039-S046", "SOR-2026-08-P039-S047"],
                "f1.3.22": ["SOR-2026-08-P039-S046", "SOR-2026-08-P039-S047"],
                "f1.3.23": ["SOR-2026-08-P039-S046", "SOR-2026-08-P039-S047"]
            }

            for p in self.passages:
                if p.get("pdf_page_index") == target_page:
                    pid = p["passage_id"]
                    # Strong boost to place the queried physical page first in evidence
                    rrf_scores[pid] = rrf_scores.get(pid, 0.0) + 0.10
                    p_art = str(p.get("article_id", "")).lower()
                    if p_art in f1_to_sec2:
                        for sub_pid in f1_to_sec2[p_art]:
                            if sub_pid in self.passages_by_id:
                                # Substantive rule gets high score to accompany the visual template
                                rrf_scores[sub_pid] = rrf_scores.get(sub_pid, 0.0) + 0.08

        # 4. Strict Abstention on domain irrelevance
        if not rrf_scores:
            return {
                "status": "ABSTAIN",
                "reason": "OUT_OF_DOMAIN",
                "message": "Sin evidencia normativa certificada en el SOR 2026-08.",
                "evidence": [],
                "related_passages": [],
                "operating_mode": self.operating_mode,
                "degradation_reason": self.degradation_reason,
                "source_sha256_verified": self.source_sha256_verified
            }

        # Reducir el peso de tablas/glosarios auxiliares: no deben desplazar evidencia normativa contextual.
        # El peso base sigue determinado por la pertinencia léxica y semántica, no por ser un encabezado "Article".
        if not requests_history:
            for pid in list(rrf_scores):
                passage = self.passages_by_id.get(pid, {})
                headings = [str(h).strip().lower() for h in passage.get("heading_path", [])]
                if any("penalty codes" in heading or "glossary" in heading for heading in headings):
                    rrf_scores[pid] *= 0.80

        # Phase 3: Referee Command Disambiguator (if enabled)
        if self.enable_referee_disambiguation:
            ref_analysis = RefereeCommandDisambiguator.analyze_query(query)
            if ref_analysis.get("intent_type") != "NONE":
                rrf_scores = RefereeCommandDisambiguator.apply_disambiguation(rrf_scores, self.passages_by_id, ref_analysis)

        # Phase 3: Lateral scoring alignment (Article 15 Waza-ari / Yuko)
        if self.enable_semantic_ranker:
            clean_q = query.lower()
            is_lateral_scoring = any(w in clean_q for w in ["costado", "perpendicular", "lateral", "90"]) and any(w in clean_q for w in ["puntuacion", "puntuación", "score", "valoracion", "valora", "cae", "caida"])
            if is_lateral_scoring:
                for pid in ("SOR-2026-08-P168-S188", "SOR-2026-08-P169-S188"):
                    if pid in self.passages_by_id:
                        rrf_scores[pid] = rrf_scores.get(pid, 0.0) + 0.12

        # Phase 3: Normative Semantic Ranker (if enabled)
        if self.enable_semantic_ranker:
            rrf_scores = NormativeSemanticRanker.rerank_scores(query, rrf_scores, self.passages_by_id)

        ranked_pids = sorted(rrf_scores.items(), key=lambda x: x[1], reverse=True)
        # Fase 11 - R3: con la preferencia de ambito activa se forma un conjunto de hasta POOL candidatos
        # (mismo filtrado y deduplicacion) que se reordena y despues se recorta a top_k.
        scope_info = None
        pool_k = top_k
        if self.scope_preference is not None and self.scope_preference.available:
            from src.scope_preference import POOL
            pool_k = max(top_k, POOL)
        top_seeds = []
        seen_texts = []
        for pid, score in ranked_pids:
            if score < min_confidence:
                continue
            p = self.passages_by_id.get(pid)
            if not p:
                continue
            raw_t = p.get("text_original", "").strip()
            is_dup = False
            for prev_t in seen_texts:
                if raw_t == prev_t:
                    is_dup = True
                    break
                if len(raw_t) > 100 and len(prev_t) > 100:
                    shorter, longer = (raw_t, prev_t) if len(raw_t) <= len(prev_t) else (prev_t, raw_t)
                    if shorter in longer and len(shorter) / len(longer) > 0.85:
                        is_dup = True
                        break
            if is_dup and len(top_seeds) >= 1:
                continue
            top_seeds.append(pid)
            seen_texts.append(raw_t)
            if len(top_seeds) >= pool_k:
                break

        if pool_k != top_k:
            parts = self.scope_preference.query_parts(domain_query or query, query)
            before = list(top_seeds[:top_k])
            top_seeds = self.scope_preference.rerank(
                top_seeds, parts, lambda x: self.passages_by_id.get(x, {}).get("pdf_page_index"))[:top_k]
            scope_info = {"applied": bool(parts), "parts": sorted(parts), "beta": self.scope_preference.beta,
                          "changed_top_k": before != top_seeds}

        if not top_seeds:
            return {
                "status": "ABSTAIN",
                "reason": "BELOW_CONFIDENCE_THRESHOLD",
                "message": "La evidencia recuperada no alcanza el umbral de certeza requerido.",
                "evidence": [],
                "related_passages": [],
                "operating_mode": self.operating_mode,
                "degradation_reason": self.degradation_reason,
                "source_sha256_verified": self.source_sha256_verified
            }

        # 5. Build structured evidence records
        evidence_list = []
        for pid in top_seeds:
            p = self.passages_by_id.get(pid)
            if p:
                if self.enable_chunk_stitching and self.stitcher:
                    stitched = self.stitcher.stitch_evidence(p)
                    rec = {
                        'passage_id': pid,  # Preserva KUN semilla como primario
                        'title': p.get('heading_path', [''])[0] if p.get('heading_path') else f"Articulo {p.get('article_id')}",
                        'article_id': p.get('article_id'),
                        'page': p.get('pdf_page_index'),
                        'score': round(rrf_scores[pid], 4),
                        'source_url': f"{p.get('source_url', '')}#page={p.get('pdf_page_index')}",
                        'text_original': stitched.get('text_original', p.get('text_original', '')),
                        'is_seed': True,
                        'is_stitched': stitched.get('is_stitched', False),
                        'composite_kun': stitched.get('composite_kun'),
                        'source_spans': stitched.get('source_spans', []),
                        'stitched_kuns': stitched.get('stitched_kuns', [pid]),
                        'is_partial_reconstruction': stitched.get('is_partial_reconstruction', False)
                    }
                    if stitched.get('reconstruction_note'):
                        rec['reconstruction_note'] = stitched['reconstruction_note']
                else:
                    rec = {
                        'passage_id': pid,
                        'title': p.get('heading_path', [''])[0] if p.get('heading_path') else f"Articulo {p.get('article_id')}",
                        'article_id': p.get('article_id'),
                        'page': p.get('pdf_page_index'),
                        'score': round(rrf_scores[pid], 4),
                        'source_url': f"{p.get('source_url', '')}#page={p.get('pdf_page_index')}",
                        'text_original': p.get('text_original', ''),
                        'is_seed': True,
                        'is_stitched': False,
                        'source_spans': [{
                            'kun': pid,
                            'page': p.get('pdf_page_index'),
                            'url': f"{p.get('source_url', '')}#page={p.get('pdf_page_index')}"
                        }]
                    }
                evidence_list.append(rec)

        # 6. Graph-Guided Cross-Reference Expansion
        related_passages = []
        if expand_graph:
            seen_targets = set(top_seeds)
            for pid in top_seeds:
                neighbors = self.graph_adj.get(pid, [])
                for n in neighbors:
                    tgt = n["target"]
                    if tgt not in seen_targets and tgt in self.passages_by_id:
                        seen_targets.add(tgt)
                        tp = self.passages_by_id[tgt]
                        related_passages.append({
                            "passage_id": tgt,
                            "source_seed": pid,
                            "relation": n["relation"],
                            "article_id": tp.get("article_id"),
                            "page": tp.get("pdf_page_index"),
                            "title": tp.get("heading_path", [""])[0] if tp.get("heading_path") else f"Art. {tp.get('article_id')}",
                            "source_url": f"{tp.get('source_url', '')}#page={tp.get('pdf_page_index')}",
                            "text_original": tp.get("text_original", "")
                        })

        # 7. Multisource Sidecar Shadow Mode Execution (Fase 4.2.3)
        # Se ejecuta en paralelo / segundo plano sin tocar jamás 'evidence_list', 'related_passages', ni modificar las respuestas canónicas.
        if self.enable_shadow_mode_multisource:
            self._execute_shadow_sidecar_retrieval(query, evidence_list)

        return {
            "status": "SUCCESS",
            "query": query,
            "evidence": evidence_list,
            "related_passages": related_passages[:3],
            "operating_mode": self.operating_mode,
            "degradation_reason": self.degradation_reason,
            "source_sha256_verified": self.source_sha256_verified,
            "scope_preference": scope_info,
        }
