# Matriz de Criterios de Aceptación Definitiva — Fase 4.2.6
## Fusión y Arbitraje Multifuente (`EvidenceBundle` & `NormativeGuard`)

**Proyecto:** SOR-IJF — IJF SOR Assistant  
**Fase:** 4.2.6 — Fusion & Arbitration Multisource  
**Supervisor y Autoridad Exclusiva de Aprobación:** Alexis Oliveros Lozano  
**Planificador y Auditoría Independiente:** ChatGPT  
**Ejecutor Técnico y Documental:** Antigravity  
**Fecha:** 2026-11-06 (Versión v3.0 Definitiva — Corrección Integral de Hallazgos V30-F01 a V30-F09)  
**Repositorio:** `C:\PROYECTOS\IJF-SOR-Assistant`  
**Estado:** **MATRIZ DE ACEPTACIÓN FORMAL DEFINITIVA — PREPARACIÓN DOCUMENTAL (ETAPA 1 NO AUTORIZADA)**

---

### Tabla de Definición de Estados de Criterios (V30-F09)
- **`PLANIFICADO`**: Criterio formalmente especificado, con método y umbral verificable definido. Código no implementado ni ejecutado.
- **`IMPLEMENTADO`**: Código desarrollado y desplegado en ramas de prueba, con suite de pruebas listas pero pendiente de certificación.
- **`VERIFICADO`**: Pruebas automatizadas y benchmarks ejecutados exitosamente con evidencias de logs y hashes contrastados.
- **`APROBADO`**: Dictamen técnico favorable de ChatGPT y firma soberana de autorización de Alexis Oliveros Lozano.

> [!IMPORTANT]
> Todos los criterios permanecen formalmente en estado **PLANIFICADO**. No se atribuye ejecución ni verificación anticipada.

---

| ID Criterio | Requisito Técnico / Normativo | Método de Verificación | Evidencia Esperada | Umbral de Aceptación | Responsable | Estado Actual |
| :--- | :--- | :--- | :--- | :--- | :--- | :--- |
| **CA-426-01** | **Seguridad Crítica Normativa (Zero-Tolerance)** | Ejecución de los 4 casos críticos de seguridad en Dataset B hold-out reservado conocido (`SEC-CRIT-01` a `SEC-CRIT-04`) evaluados individualmente contra sus oráculos canónicos textuales verificados en fuente primaria (SOR 2026 pág. 166-167, 184-185, 189, 191) mediante el comparador de 12 dimensiones, selección canónica multi-candidata y exclusión estricta de Sidecars no estructurados o en ramas fail-closed. | Log de ejecución con bloqueo determinista de excepciones de seguridad en puente de cuello (Ippon), edad (cadetes), llaves prohibidas (Hansoku-make) y vestimenta (Shido). | **0 fallos (4/4 PASS estricto, 100.0%). Cero atenuantes permitidos.** | Antigravity / ChatGPT | **PLANIFICADO** |
| **CA-426-02** | **Invarianza Canónica Primaria RRE** | Comparación campo a campo entre Baseline y Fusion Mode en consultas SOR puras: identidad exacta discreta de `passage_id` y orden; scores flotantes con delta $< 10^{-4}$. | Diff de salida en memoria comprobando igualdad discreta de identificadores y delta numérico flotante. | **100.0% identidad de pasajes y orden; delta flotante $< 10^{-4}$** | Antigravity | **PLANIFICADO** |
| **CA-426-03** | **Invarianza Dispositiva ADA** | Comparación estructurada de tuplas de mandatos `(Acción, Sujeto, Prohibición/Obligación)` y sanciones `{Ippon, Waza-ari, Yuko, Shido, Hansoku-make directo, No sanción}` en consultas canónicas. | Reporte de análisis determinista reproducible mediante parser de tuplas normativas. | **100.0% concordancia dispositiva en mandatos, sanciones y excepciones** | Antigravity / ChatGPT | **PLANIFICADO** |
| **CA-426-04** | **Tratamiento de Edad Desconocida** | Verificación de que ante consulta con edad no identificada, el sistema no asuma Cadetes automáticamente sino que active desambiguación interactiva o presente ambas condiciones diferenciadas. | Tests unitarios de `ScopeApplicability` y respuestas estructuradas diferenciando Senior de Cadetes/Junior. | **0 extrapolaciones erróneas (100.0% cumplimiento)** | Antigravity | **PLANIFICADO** |
| **CA-426-05** | **Evaluación Dispositiva en `NormativeGuard`** | Verificación de que consultas explicativas sobre Art. 14, 18.2 o Apéndice C no sean bloqueadas por mera mención, pero se purgue toda excepción ilegítima contra normas imperativas con enum cerrado `GuardActionTaken`, selección multi-candidata canónica y los 12 invariantes ejecutables cumplidos (incluyendo el Invariante 12 de desacoplamiento de suficiencia). | Tests unitarios demostrando admisión de consultas canónicas doctrinales y rechazo estricto de excepciones de seguridad con causas justificadas. | **100.0% admisión legítima y 100.0% bloqueo de falsas excepciones** | Antigravity | **PLANIFICADO** |
| **CA-426-06** | **Custodia y Desempeño en Dataset B (Hold-Out Reservado Conocido)** | Verificación de aislamiento criptográfico de `benchmark_dataset_b_certificacion_ijf.json` (hash inmutable) y ejecución automatizada de las 20 consultas hold-out en Etapa 4, reconociendo explícitamente las limitaciones metodológicas de exposición local y separando integridad de independencia experimental. | Reporte forense con cálculo de recall, supresión OOD, invarianza y arbitraje sobre dataset reservado conocido no visto en tests de desarrollo. | **Hash inalterado; $\ge 85.0\%$ PASS global ($\ge 17/20$)** | Antigravity / ChatGPT | **PLANIFICADO** |
| **CA-426-07** | **Preservación de Tests Preexistentes y Crecimiento Planificado** | Ejecución de suite pytest completa sobre todo el repositorio asegurando la preservación de los 267 tests base más los tests incrementales planificados por etapa (meta: 286 tests). | Log de ejecución de pytest reportando pruebas superadas sin fallos ni errores tras implementar cada etapa autorizada. | **Meta planificada: $\ge 286$ tests PASSED (0 regresiones en los 267 originales)** | Antigravity | **PLANIFICADO** |
| **CA-426-08** | **Integridad Criptográfica de Activos de Datos Físicos** | Recálculo de hashes SHA-256 sobre los 6 archivos físicos del corpus oficial y Sidecars ingestados en disco (diferenciados del código protegido `src/rre_engine.py`). | Tabla comparativa de hashes contrastada contra la línea base certificada. | **6 de 6 hashes con MATCH EXACTO** | Antigravity | **PLANIFICADO** |
| **CA-426-09** | **Latencia y Overhead Computacional** | Medición de alta resolución (`time.perf_counter()`) con 1 ciclo de warm-up y 3 pasadas sobre las 40 consultas del benchmark. | Estadísticas de latencia media, mediana, P95 y desviación estándar. | **Overhead de arbitraje $\Delta_{\text{mean}} \le 5.0\text{ ms}$; $P95 \le 80.0\text{ ms}$** | Antigravity | **PLANIFICADO** |
| **CA-426-10** | **Gobernanza Operativa de Feature Flags** | Verificación de contrato tri-estado en `enable_multisource_fusion: Optional[bool] = None`, precedencia sobre `RRE_ENABLE_MULTISOURCE_FUSION` y fallback seguro a `False`. | Tests de inicialización y precedencia confirmando que el valor resuelto por defecto es `False` y que el flag controla la instanciación. | **`enable_multisource_fusion = False` por defecto; desacoplamiento total** | Antigravity / ChatGPT | **PLANIFICADO** |
| **CA-426-11** | **Evidencia Verificable de Aislamiento** | Comprobación de estado del árbol de trabajo (`git status`, `git diff`) y verificación de repositorios remotos sin operaciones de push ni intervención productiva. | Reporte de auditoría confirmando 0 commits remotos, 0 push, 0 branches publicadas y 0 interacciones OCI. | **0 acciones remotas ejecutadas (Evidencia auditable)** | Alexis Oliveros / Antigravity | **PLANIFICADO — NO EJECUTADO — NO CERTIFICADO** |
