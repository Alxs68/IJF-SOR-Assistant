import unittest
import os
import sys
import json
from unittest.mock import patch, MagicMock

sys.path.append(os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), 'src'))

from response_structurer import (
    StructuredAnswer,
    parse_structured_response,
    build_deterministic_structured_answer,
    clean_presentation_text,
    sanitize_presentation_html
)
from ada_assistant import ArbitrationDecisionAssistant
from llm_provider import MultiProviderLLMManager
from tests._ada_contract_helpers import (
    StubLLM, answer_citing, cite_first_delivered, citation_ids,
    delivered_ids_in_result, delivered_primary_ids, ABSTENTION_MARKER, TRANSLATION_MARKER,
)


class TestResponseStructurerTransversal(unittest.TestCase):

    def test_01_parse_valid_json_response(self):
        sample_json = json.dumps({
            "summary": "El tatami mide 8x8m a 10x10m con zona de seguridad de 3m.",
            "normative_basis": "Regla 8.7 página 96.",
            "citations": ["SOR-2026-08-P096-S114"],
            "conditions_and_exceptions": "En World Championships es obligatorio 10x10m.",
            "extended_analysis": "Explicación detallada del campo de juego.",
            "limitations": "Solo aplica a eventos oficiales de la IJF."
        })
        parsed = parse_structured_response(sample_json)
        self.assertTrue(parsed.is_structured)
        self.assertEqual(parsed.summary, "El tatami mide 8x8m a 10x10m con zona de seguridad de 3m.")
        self.assertEqual(parsed.normative_basis, "Regla 8.7 página 96.")
        self.assertEqual(parsed.citations, ["SOR-2026-08-P096-S114"])
        self.assertIn("World Championships", parsed.conditions_and_exceptions)
        self.assertIn("Explicación detallada", parsed.extended_analysis)
        self.assertIn("Solo aplica", parsed.limitations)

    def test_02_parse_markdown_fenced_json(self):
        fenced = """Aquí está el resultado:
```json
{
  "summary": "En cadetes se sanciona con shido el uso de la cabeza para defenderse.",
  "normative_basis": "Art. 18.1.4 pág. 188.",
  "citations": ["SOR-2026-08-P255-S269"],
  "conditions_and_exceptions": "Si no hay peligro es shido; si crea peligro es hansoku-make.",
  "extended_analysis": "Análisis arbitral de protección cervical.",
  "limitations": ""
}
```
"""
        parsed = parse_structured_response(fenced)
        self.assertTrue(parsed.is_structured)
        self.assertIn("En cadetes se sanciona con shido", parsed.summary)
        self.assertIn("Art. 18.1.4", parsed.normative_basis)

    def test_03_fallback_unstructured_multisection_text(self):
        unstructured = """⚖️ **Síntesis Analítica IA (Gemini)**

El entrenador no puede dar instrucciones durante el combate, solo durante mate y hajime.

### 1. Preceptos Oficiales
Artículo 7.1 Código de Conducta de Entrenadores.

### 2. Sanciones
Suspensión del evento si reincide."""
        parsed = parse_structured_response(unstructured)
        self.assertFalse(parsed.is_structured)
        self.assertIn("El entrenador no puede dar instrucciones", parsed.summary)
        self.assertNotIn("⚖️ **Síntesis Analítica IA", parsed.summary)
        self.assertIn("Artículo 7.1", parsed.extended_analysis)

    def test_04_fallback_empty_or_whitespace_response(self):
        parsed = parse_structured_response("")
        self.assertFalse(parsed.is_structured)
        self.assertIn("No se recibió contenido", parsed.summary)
        self.assertIn("vacía", parsed.limitations)

    def test_05_deterministic_offline_structured_answer(self):
        mock_evidence = [{
            "passage_id": "SOR-2026-08-P096-S114",
            "title": "Field of Play",
            "article_id": "8.7",
            "page": 96,
            "text_original": "The contest area shall be a minimum of 8 m x 8 m and a maximum of 10 m x 10 m."
        }]
        mock_related = [{
            "passage_id": "SOR-2026-08-P095-S113",
            "title": "Tatami Safety",
            "article_id": "8.6",
            "page": 95,
            "relation": "safety_boundary"
        }]
        structured = build_deterministic_structured_answer(
            query="dimensiones del tatami",
            evidence=mock_evidence,
            related=mock_related,
            version_label="14 August 2026 (Official)"
        )
        self.assertTrue(structured.is_structured)
        self.assertIn("Field of Play", structured.summary)
        self.assertIn("Art. 8.7", structured.summary)
        self.assertIn("Pág. 96", structured.summary)
        self.assertIn("[SOR-2026-08-P096-S114]", structured.summary)
        self.assertIn("Extracto Oficial:", structured.normative_basis)
        self.assertIn("safety_boundary", structured.conditions_and_exceptions)
        self.assertIn("Modo Local Desconectado", structured.limitations)

    def test_06_ada_analyze_situation_two_tier_contract(self):
        """Two-tier contract under the evidence policy (stubbed generator, no network).

        Without a generator ADA abstains but keeps the two-tier fields and the retrieved evidence;
        with a generator citing a delivered primary passage the two-tier answer carries that citation.
        """
        mgr = MultiProviderLLMManager(gemini_api_key=None, groq_api_key=None)
        ada = ArbitrationDecisionAssistant(llm_manager=mgr)
        query = "¿Cuáles son las dimensiones del tatami?"
        tatami_pid = "SOR-2026-08-P096-S114"
        fields = ("summary", "normative_basis", "conditions_and_exceptions", "extended_analysis", "limitations")

        with patch.object(ada, "_call_llm", StubLLM()):
            offline = ada.analyze_situation(query)
        self.assertEqual(offline["status"], "ABSTAIN")
        for key in fields:
            self.assertIn(key, offline["structured_answer"])
        self.assertEqual(offline["structured_answer"]["citations"], [])
        self.assertIn(ABSTENTION_MARKER, offline["structured_answer"]["summary"])
        self.assertIn(tatami_pid, delivered_ids_in_result(offline))

        stub = StubLLM(answer_citing(lambda delivered: [tatami_pid] if tatami_pid in delivered else []))
        with patch.object(ada, "_call_llm", stub):
            res = ada.analyze_situation(query)
        self.assertIn(tatami_pid, delivered_primary_ids(stub.analysis_prompts[0]))
        self.assertEqual(res["status"], "SUCCESS")
        struct = res["structured_answer"]
        for key in fields:
            self.assertIn(key, struct)
        self.assertTrue(len(struct["summary"]) > 20)
        # Clickable citation formatting applied to the cited, delivered passage
        self.assertIn(tatami_pid, struct["summary"])
        self.assertEqual(citation_ids(res), [tatami_pid])

    def test_07_ada_abstain_query_structured_contract(self):
        mgr = MultiProviderLLMManager(gemini_api_key=None, groq_api_key=None)
        ada = ArbitrationDecisionAssistant(llm_manager=mgr)
        res = ada.analyze_situation("reglas de fuera de juego en baloncesto nba y formula 1")

        self.assertEqual(res["status"], "ABSTAIN")
        self.assertIn("structured_answer", res)
        struct = res["structured_answer"]
        self.assertIn("Abstención Normativa Oficial", struct["summary"])
        self.assertEqual(len(res["evidence"]), 0)


    def test_08_clean_presentation_text(self):
        raw = "⚖️ **Síntesis Analítica IA (Gemini)**\n\nEl tatami mide 8x8m [SOR-2026-08-P096-S114](https://example.com#page=96). Referencia:."
        cleaned = clean_presentation_text(raw)
        self.assertNotIn("Síntesis Analítica IA", cleaned)
        self.assertNotIn("SOR-2026-08", cleaned)
        self.assertNotIn("https://example.com", cleaned)
        self.assertNotIn("Referencia:.", cleaned)
        self.assertIn("El tatami mide 8x8m", cleaned)

    def test_09_sanitize_presentation_html_security(self):
        # AUD-05: Injection attack and XSS neutralization
        unsafe = "<script>alert('xss')</script> **Tori** debe medir < 60cm & pesar > 50kg.\n\n*Nota:* reglamentario."
        sanitized = sanitize_presentation_html(unsafe)
        self.assertNotIn("<script>", sanitized)
        self.assertIn("&lt;script&gt;alert(&#x27;xss&#x27;)&lt;/script&gt;", sanitized)
        self.assertIn("&lt; 60cm &amp; pesar &gt; 50kg.", sanitized)
        self.assertIn("<strong>Tori</strong>", sanitized)
        self.assertIn("<em>Nota:</em>", sanitized)
        self.assertIn("<br><br>", sanitized)


if __name__ == "__main__":
    unittest.main()
